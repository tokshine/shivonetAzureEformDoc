﻿using System.Collections.Generic;
using Workwiz.Islington.DocumentStore.Shared;

namespace Workwiz.Islington.DocumentStore.Infrastructure
{
    public interface IStorageService
    {
        void UploadDocument(DocumentDto document);
        DocumentDto GetDocument(string fullPath);
        IEnumerable<DocumentDto> GetDocuments(string folderPath);
        void DeleteDocument(string fullPath);

        string GenerateDocumentLink(string fullPath);
    }
}