﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Workwiz.Lbi.DocumentStore.Shared;
using Workwiz.Lbi.DocumentStore.Infrastructure.Properties;


namespace Workwiz.Lbi.DocumentStore.Infrastructure
{

    public  class CloudService : UtilService
    {
        public static void UploadDocument(IEnumerable<DocumentDto> documents)
        {
            CloudBlobContainer blobContainer = BlobContainer;
            foreach (var document in documents)
            {
                CloudBlockBlob azureBlockBlob = blobContainer.GetBlockBlobReference(document.FileName);
                azureBlockBlob.UploadFromStream(document.Stream);
            }
        }

        public static void UploadDocument(IEnumerable<DocumentDto> documents, int? businessId =0 ,int? formId =0)
        {
            CloudBlobContainer blobContainer = BlobContainer;
            string prefix = string.Format("{0}/{1}/", businessId.GetValueOrDefault(), formId.GetValueOrDefault());
            foreach (var document in documents)
            {
                CloudBlockBlob azureBlockBlob = blobContainer.GetBlockBlobReference(prefix + document.FileName);
                azureBlockBlob.UploadFromStream(document.Stream);
            }
        }

        public static IEnumerable<CloudFileDto> GetCloudFiles(int? businessId,int? formId)
        {
            CloudBlobContainer blobContainer = BlobContainer;
            string directory = string.Format("{0}/{1}", businessId.GetValueOrDefault(), formId.GetValueOrDefault());
            CloudBlobDirectory blobDirectory = blobContainer.GetDirectoryReference(directory);
            CloudFiles blobsList = new
                CloudFiles(blobDirectory.ListBlobs(true));

            var list = new List<CloudFileDto>();
            var files = blobsList.Files.OrderBy(x => x.FileName);
            foreach (var item in files)
            {
                var cloudFileDto = new CloudFileDto();
                cloudFileDto.FileName = Path.GetFileName(item.FileName);
                cloudFileDto.Size = item.Size;
                cloudFileDto.URL = GenerateTimeLimitedDownloadUrl(businessId,formId, cloudFileDto.FileName);
                list.Add(cloudFileDto);
            }

            return list;
        }

        public static void DeleteDocument(string fileName, int businessId,int formId)
        {
            
            var blobName = GetBlobName(businessId, formId, fileName);
            CloudBlobContainer blobContainer = BlobContainer;
            CloudBlockBlob blob = blobContainer.GetBlockBlobReference(blobName);
            blob.Delete();
        }


      

      

      
    }

}