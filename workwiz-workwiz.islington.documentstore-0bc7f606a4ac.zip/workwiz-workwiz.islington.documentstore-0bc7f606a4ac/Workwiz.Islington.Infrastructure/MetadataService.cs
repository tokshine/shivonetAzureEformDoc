﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Workwiz.Common.Azure.DocumentDB;
using Workwiz.Islington.DocumentStore.Shared;

namespace Workwiz.Islington.DocumentStore.Infrastructure
{
    public class MetadataService : IMetadataService
    {
        private DocumentClient _documentClient;
        private Uri _defaultCollectionLink;

        public MetadataService()
        {
            DocumentDbConnectionParameters docDbConfig = DocumentDbConnectionParameters.ParseConnectionString(
                Properties.Settings.Default.MetaDataDb,
                "MetaDataDb");
            var documentDbConnectionFactory = new DocumentDbConnectionFactory(
                docDbConfig,
                Microsoft.Azure.Documents.ConsistencyLevel.Strong);
            _documentClient = documentDbConnectionFactory.CreateClient();
            _defaultCollectionLink = documentDbConnectionFactory.DefaultCollectionLink;
            documentDbConnectionFactory.EnsureDefaultDatabaseAndCollection();
        }
        public async Task<dynamic> CreateDocumentMetadata(dynamic metadata)
        {
            await _documentClient.CreateDocumentAsync(_defaultCollectionLink, metadata);
            return metadata;
        }

        public async Task DeleteDocumentMetadata(string guid)
        {
           
            var sqlQuerySpec = new SqlQuerySpec
            {
                QueryText = "SELECT * FROM c WHERE c.Guid = @Guid",
                Parameters = new SqlParameterCollection()
                {
                          new SqlParameter("@Guid",guid)
                 }
            };


            var documentLink =
                _documentClient.CreateDocumentQuery<Document>(_defaultCollectionLink, sqlQuerySpec)
                    .AsEnumerable()
                    .FirstOrDefault();
            await _documentClient.DeleteDocumentAsync(documentLink.SelfLink);
        }

        public IEnumerable<dynamic> Search(dynamic metadata)
        {
            var sql = "SELECT VALUE c FROM c WHERE " + BuildSqlWhereClause(metadata);
            var list = _documentClient.CreateDocumentQuery(_defaultCollectionLink,
                sql);           
            return list;
        }

        public async Task<string> UpdateDocumentMetadata(dynamic metadata)
        {
            var sql = "SELECT VALUE c FROM c WHERE " + BuildSqlWhereClause(metadata);
            var documents = _documentClient.CreateDocumentQuery(_defaultCollectionLink, sql).ToList();
            if (!documents.Any()) throw new Exception("Document metadata not found");
            var document = documents.First();
            document.IsProcessed = true;
            await _documentClient.ReplaceDocumentAsync(document._self, document);
            return "Metadata updated ";
        }
       

        #region Private methods

        private string BuildSqlWhereClause(dynamic documentMetadata)
        {
            var sqlBuilder = new StringBuilder();

            if (!string.IsNullOrEmpty(documentMetadata.ResponseId))
            {
                sqlBuilder.Append($"c.ResponseId=\"{documentMetadata.ResponseId}\"");

                if (!string.IsNullOrEmpty(documentMetadata.Guid))
                {
                    sqlBuilder.Append($" AND c.Guid=\"{documentMetadata.Guid}\"");
                }

                return sqlBuilder.ToString();
            }

            if (!string.IsNullOrEmpty(documentMetadata.Guid))
            {
                sqlBuilder.Append($"c.Guid=\"{documentMetadata.Guid}\"");
                return sqlBuilder.ToString();
            }

            if (!string.IsNullOrEmpty(documentMetadata.FormId) && int.Parse(documentMetadata.FormId) > 0)
            {
                sqlBuilder.Append($"c.FormId=\"{documentMetadata.FormId}\"");
                if (!string.IsNullOrEmpty(documentMetadata.BusinessId) && int.Parse(documentMetadata.BusinessId) > 0)
                {
                    sqlBuilder.Append($" AND c.BusinessId=\"{documentMetadata.BusinessId}\"");
                }

                if (!string.IsNullOrEmpty(documentMetadata.Filename))
                {
                    sqlBuilder.Append($" AND c.FileName=\"{documentMetadata.FileName}\"");
                }

                return sqlBuilder.ToString();
            }



            if (!string.IsNullOrEmpty(documentMetadata.Topic))
            {
                sqlBuilder.Append($"c.Topic=\"{documentMetadata.Topic}\"");
                if (!string.IsNullOrEmpty(documentMetadata.BusinessId) && int.Parse(documentMetadata.BusinessId) > 0)
                {
                    sqlBuilder.Append($" AND c.BusinessId=\"{documentMetadata.BusinessId}\"");
                }

                if (!string.IsNullOrEmpty(documentMetadata.Filename))
                {
                    sqlBuilder.Append($" AND c.FileName=\"{documentMetadata.FileName}\"");
                }


                if (!string.IsNullOrEmpty(documentMetadata.UserId))
                {
                    sqlBuilder.Append($"c.UserId=\"{documentMetadata.UserId}\"");
                }

                return sqlBuilder.ToString();
            }

            if (!string.IsNullOrEmpty(documentMetadata.BusinessId) && int.Parse(documentMetadata.BusinessId) > 0)
            {
                sqlBuilder.Append($"c.BusinessId=\"{documentMetadata.BusinessId}\"");
                return sqlBuilder.ToString();
            }

            if (!string.IsNullOrEmpty(documentMetadata.UserId))
            {
                sqlBuilder.Append($"c.UserId=\"{documentMetadata.UserId}\"");
            }

            return sqlBuilder.ToString();
        }

        #endregion
    }
}
