﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Workwiz.Common.Azure.DocumentDB;
using Workwiz.Lbi.DocumentStore.Shared;
using Workwiz.Lbi.DocumentStore.Infrastructure.Properties;


namespace Workwiz.Lbi.DocumentStore.Infrastructure
{
    public class DocumentDbService : UtilService
    {
        internal static DocumentDbConnectionFactory DbConnectionFactory;

        public static void CreateDocumentMetadata(DocumentContainerDto documentDto)
        {
            using (var client = DbConnectionFactory.CreateClient())
            {
                CreateDocuments(client, documentDto);
            }
        }

        public static void CreateDocumentMetadata(IEnumerable<DocumentDto> documents)
        {
            using (var client = DbConnectionFactory.CreateClient())
            {
                CreateMetadata(client, documents);
            }
        }

        public static void DeleteDocumentMetadata(string fileName, int businessId, int formId)
        {
            using (var client = DbConnectionFactory.CreateClient())
            {
                DeleteDocumentMetadata(client, fileName, businessId, formId);
            }
        }

        public static IEnumerable<DocumentMetadataDto> GetDocumentMetadata(int? businessId, int? formId)
        {

            using (var client = DbConnectionFactory.CreateClient())
            {
                return GetDocumentMetadata(client, businessId, formId);
            }
        }

        public static string UpdateDocumentMetadata(int businessId, int formId, string filename, bool isProcessed)
        {

            using (var client = DbConnectionFactory.CreateClient())
            {
                return UpdateDocumentMetadata(client, businessId, formId, isProcessed, filename);
            }
        }

        private static string UpdateDocumentMetadata(DocumentClient client, int businessId, int formId, bool isProcessed, string filename)
        {
            var sql = string.Format("SELECT * FROM c WHERE c.FormId ='{0}'  and c.BusinessId='{1}'  and c.Filename='{2}'", formId, businessId, filename);

            var documents = client.CreateDocumentQuery(DbConnectionFactory.DefaultCollectionLink, sql).ToList();
            if (!documents.Any()) throw new Exception("Document metadata not found");
            var document = documents.First();
            document.IsProcessed = isProcessed;
            client.ReplaceDocumentAsync(document._self, document);
            return "Metadata updated ";
        }

        public static void DeleteDocumentMetadata(int businessId, int formId)
        {
            using (var client = DbConnectionFactory.CreateClient())
            {
                DeleteDocumentMetadata(client, businessId, formId);
            }
        }

        private static void CreateDocuments(DocumentClient client, DocumentContainerDto documentContainerDto)
        {
            var documents = documentContainerDto.Documents;
            var businessId = documentContainerDto.BusinessId;
            var formId = documentContainerDto.FormId;
            CreateMetadata(client, documents, formId, businessId);

        }

        private static void CreateMetadata(DocumentClient client, IEnumerable<DocumentDto> documents, int? formId = 0, int? businessId = 0)
        {
            foreach (var doc in documents)
            {
                var documentMetaData = new DocumentMetadataDto
                {
                    Filename = doc.FileName,
                    FormId = formId.ToString(),
                    BusinessId = businessId.ToString(),
                    DateSubmitted = DateTime.UtcNow,
                    FileSize = doc.FileSize.ToString(),
                    MimeType = doc.FileType
                };
                CreateDocument(client, documentMetaData);
            }
        }

        private static ResourceResponse<Document> CreateDocument(DocumentClient client, object documentObject)
        {
            var result = client.CreateDocumentAsync(DbConnectionFactory.DefaultCollectionLink, documentObject);
            return result.Result;
        }


        private static void DeleteDocumentMetadata(DocumentClient client, int businessId, int formId)
        {
            var sql = string.Format("SELECT VALUE c._self FROM c WHERE c.FormId =\"{0}\" and c.BusinessId=\"{1}\" ", formId, businessId);
            var documentLinks = client.CreateDocumentQuery<string>(DbConnectionFactory.DefaultCollectionLink, sql).ToList();
            foreach (var documentLink in documentLinks)
            {
                var result = client.DeleteDocumentAsync(documentLink).Result;
            }
        }
        private static void DeleteDocumentMetadata(DocumentClient client, string fileName, int businessId, int formId)
        {
            var sql = string.Format("SELECT VALUE c._self FROM c WHERE c.FormId =\"{0}\" and c.BusinessId=\"{1}\" and c.Filename = \"{2}\"", formId, businessId, fileName);
            var documentLinks = client.CreateDocumentQuery<string>(DbConnectionFactory.DefaultCollectionLink, sql).ToList();
            foreach (var documentLink in documentLinks)
            {
                var result = client.DeleteDocumentAsync(documentLink).Result;
            }
        }

        private static IEnumerable<DocumentMetadataDto> GetDocumentMetadata(DocumentClient client, int? businessId = 0, int? formId = 0)
        {
            var metaDataCollection = new List<DocumentMetadataDto>();
            var sqlStringbuilder = new StringBuilder("SELECT * FROM c WHERE 1=1 ");

            string whereClause = string.Empty;
            if (formId > 0)
            {
                whereClause = string.Format(" and c.FormId =\"{0}\"", formId);
            }
            if (businessId > 0)
            {
                whereClause += string.Format(" and c.BusinessId=\"{0}\" ", businessId);
            }
            sqlStringbuilder.Append(whereClause);
            var metadata = client.CreateDocumentQuery(DbConnectionFactory.DefaultCollectionLink, sqlStringbuilder.ToString()).ToList();
            foreach (var item in metadata)
            {
                var meta = (DocumentMetadataDto)
                      (new JavaScriptSerializer()).Deserialize(item.ToString(), typeof(DocumentMetadataDto));
                meta.ExpiryUrl = GenerateTimeLimitedDownloadUrl(businessId, formId, meta.Filename);
                metaDataCollection.Add(meta);
            }
            return metaDataCollection;
        }
    }
}