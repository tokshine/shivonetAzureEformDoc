﻿using System;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Workwiz.Lbi.DocumentStore.Infrastructure.Properties;

namespace Workwiz.Lbi.DocumentStore.Infrastructure
{
    public abstract class UtilService
    {
        private const string AppKeyBlobContainer = "Workwiz.Lbi.DocumentStore:BlobContainer";

        private static Lazy<CloudBlobContainer> _blobContainer = new Lazy<CloudBlobContainer>(GetCloudBlobContainer, System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);
        protected static CloudBlobContainer BlobContainer
        {
            get
            {
                return _blobContainer.Value;
            }
        }

        private static CloudBlobContainer GetCloudBlobContainer()
        {
            string blobContainerName = System.Configuration.ConfigurationManager.AppSettings[AppKeyBlobContainer];
            if (String.IsNullOrEmpty(blobContainerName))
            {
                throw new Exception($"Missing configuration key {AppKeyBlobContainer}");
            }
            // blob container name must be all lower-case otherwise can't create!
            blobContainerName = blobContainerName.ToLower();
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(Settings.Default.StorageConnectionString);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer blobContainer = blobClient.GetContainerReference(blobContainerName);
            if (blobContainer.CreateIfNotExists())
            {
                blobContainer.SetPermissions(new BlobContainerPermissions()
                {
                    PublicAccess = BlobContainerPublicAccessType.Off
                });
            }

            return blobContainer;
        }

        protected static string GenerateTimeLimitedDownloadUrl
         (int? businessId, int? formId, string fileName)
        {
            var blobItem = GetBlobReference(businessId, formId, fileName);

            SharedAccessBlobPolicy sasConstraints = new SharedAccessBlobPolicy();
            sasConstraints.SharedAccessStartTime = DateTime.UtcNow;
            sasConstraints.SharedAccessExpiryTime = DateTime.UtcNow.AddMinutes(1);
            sasConstraints.Permissions = SharedAccessBlobPermissions.Read | SharedAccessBlobPermissions.Write;

            //Generate the shared access signature on the blob, setting the constraints directly on the signature.
            string sasBlobToken = blobItem.GetSharedAccessSignature(sasConstraints);

            return blobItem.Uri.ToString() + sasBlobToken;
            // NOTE the neater-looking return new Uri(bloblItem.Uri, sasBlobToken) will NOT work as expected!
            // if the sig-field contains a '%2B', then Uri.ToString will be too clever and convert it incorrectly
            // to a '+' which breaks the signature!  callers must then know to use Uri.OriginalString instead,
            // resulting in the possibly intermittant issues with bad signatures if the caller were to use
            // ToString() without knowing 
        }
        private static CloudBlockBlob GetBlobReference(int? businessId, int? formId, string fileName)
        {
            CloudBlobContainer blobContainer = BlobContainer;

            var blobName = GetBlobName(businessId, formId, fileName);
            CloudBlockBlob azureBlockBlob = blobContainer.GetBlockBlobReference(blobName);

            return azureBlockBlob;
        }

        protected static string GetBlobName(int? businessId, int? formId, string fileName)
        {
            var blobName = string.Format("{0}/{1}/{2}", businessId.GetValueOrDefault(), formId.GetValueOrDefault(), fileName);
            return blobName;
        }
    }
}