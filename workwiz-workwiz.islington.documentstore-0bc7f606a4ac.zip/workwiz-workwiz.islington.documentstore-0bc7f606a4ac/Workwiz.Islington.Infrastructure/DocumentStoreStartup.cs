﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Common.Azure.DocumentDB;

namespace Workwiz.Lbi.DocumentStore.Infrastructure
{
    public static class DocumentStoreStartup
    {
        public static async Task InitializeStorage()
        {
            DocumentDbConnectionParameters docDbConfig = DocumentDbConnectionParameters.ParseConnectionString(
                Properties.Settings.Default.MetaDataDb,
                "MetaDataDb");
            DocumentDbConnectionFactory docDbFactory = new DocumentDbConnectionFactory(
                docDbConfig,
                Microsoft.Azure.Documents.ConsistencyLevel.Strong);
            DocumentDbService.DbConnectionFactory = docDbFactory;
            await docDbFactory.EnsureDefaultDatabaseAndCollection();
        }
    }
}
