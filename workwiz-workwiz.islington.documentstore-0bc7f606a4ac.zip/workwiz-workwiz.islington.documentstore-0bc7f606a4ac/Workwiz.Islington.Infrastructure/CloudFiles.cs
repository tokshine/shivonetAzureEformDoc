﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.WindowsAzure.Storage.Blob;

namespace Workwiz.Lbi.DocumentStore.Infrastructure
{

    public class CloudFiles
    {
        public CloudFiles()
            : this(null)
        {
            Files = new List<CloudFile>();
        }
        public CloudFiles(IEnumerable<IListBlobItem> list)
        {
            Files = new List<CloudFile>();
            if (list != null && list.Any())
            {
                foreach (var item in list)
                {
                    CloudFile info = CloudFile.CreateFromIListBlobItem(item);
                    if (info != null)
                    {
                        Files.Add(info);
                    }
                }
            }
        }
        public List<CloudFile> Files { get; set; }
    }
}
