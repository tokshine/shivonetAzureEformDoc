using System.Collections.Generic;
using System.Threading.Tasks;
using Workwiz.Islington.DocumentStore.Shared;

namespace Workwiz.Islington.DocumentStore.Infrastructure
{
    public interface IMetadataService
    {
        Task<dynamic> CreateDocumentMetadata(dynamic metadata);
        Task DeleteDocumentMetadata(string guid);
        IEnumerable<dynamic> Search(dynamic metadata);
        Task<string> UpdateDocumentMetadata(dynamic metadata);
    }
}