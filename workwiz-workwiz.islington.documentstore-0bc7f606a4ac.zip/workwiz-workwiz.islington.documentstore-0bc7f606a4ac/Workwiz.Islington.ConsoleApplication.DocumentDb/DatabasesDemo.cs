﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;

namespace Workwiz.ConsoleApplication.DocumentDb
{
	public static class DatabasesDemo
	{
	    private static Database _database;
        private static DocumentCollection _collection;
        public  async static Task Run()
		{
			//Debugger.Break();

			var endpoint = ConfigurationManager.AppSettings["DocDbEndpoint"];
			var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];

			using (var client = new DocumentClient(new Uri(endpoint), masterKey))
			{
                //ViewDatabases(client);

                //await CreateDatabase(client);
                //ViewDatabases(client);

                //await DeleteDatabase(client);
                ViewDatabase(client);
                //ViewCollections(client);
                GetCollection(client, "businessratedocuments");
                await CreateDocuments(client);
			    QueryDocumentsWithSql(client, "1");
			}
		}

        private async static Task CreateDocuments(DocumentClient client)
        {
            Console.WriteLine();
            Console.WriteLine(">>> Create Documents <<<");

            var documentMetaData = new EFormDocument
            {
                FileUrl="http://yourfile.file",
                Filename="test3.xml",
                FormId="1",
                BusinessId="1",
                DateSubmitted=DateTime.UtcNow,
                FileSize="2M",
                MimeType="JPG"
            };
            Document document3 = await CreateDocument(client, documentMetaData);
            Console.WriteLine("Created document {0} from JSON string", document3.Id);
            Console.WriteLine();

        }

        private async static Task<Document> CreateDocument(DocumentClient client, string documentJson)
        {
            var documentObject = new JavaScriptSerializer().Deserialize<object>(documentJson);
            return await CreateDocument(client, documentObject);
        }



	    private static void QueryDocumentsWithSql(DocumentClient client,string formId)
	    {
	        Console.WriteLine();
	        Console.WriteLine(">>> Query Documents (SQL) <<<");
	        Console.WriteLine();

	        Console.WriteLine("Quering for new customer documents (SQL)");
	        var sql = string.Format("SELECT * FROM c where c.FormId =\"{0}\"",formId);

            var documents = client.CreateDocumentQuery<EFormDocument>(_collection.SelfLink, sql).ToList();
	        Console.WriteLine("Found {0} new documents", documents.Count);
	        foreach (var document in documents)
	        {
	            Console.WriteLine(" Filename: {0}; Size: {1};", document.Filename, document.MimeType);
	           
	        }
	    }

	    private async static Task<Document> CreateDocument(DocumentClient client, object documentObject)
        {
            var result = await client.CreateDocumentAsync(_collection.SelfLink, documentObject);
            var document = result.Resource;
            Console.WriteLine("Created new document: {0}\r\n{1}", document.Id, document);
            return result;
        }

        private  static void GetCollection(DocumentClient client, string collectionId)
	    {
            Console.WriteLine();
            Console.WriteLine(">>> View Collection {0} in {1} <<<", collectionId, _database.Id);

            var query = new SqlQuerySpec
            {
                QueryText = "SELECT * FROM c WHERE c.id = @id",
                Parameters = new SqlParameterCollection { new SqlParameter { Name = "@id", Value = collectionId } }
            };
           _collection = client.CreateDocumentCollectionQuery(_database.SelfLink, query).AsEnumerable().First();

            ViewCollection();
        }

	    private static void ViewDatabases(DocumentClient client)
		{
			Console.WriteLine();
			Console.WriteLine(">>> View Databases <<<");

			 var databases = client.CreateDatabaseQuery().ToList();
			foreach (var database in databases)
			{
				Console.WriteLine(" Database Id: {0}; Rid: {1}", database.Id, database.ResourceId);
			}

			Console.WriteLine();
			Console.WriteLine("Total databases: {0}", databases.Count);
		}

        private  static void  ViewDatabase(DocumentClient client)
        {
            Console.WriteLine();
            Console.WriteLine(">>> View Database <<<");

             _database = client
                .CreateDatabaseQuery("SELECT * FROM c WHERE c.id = 'eform-documents'")
                .AsEnumerable()
                .First();
            Console.WriteLine(" Database Id: {0}; Rid: {1}", _database.Id, _database.ResourceId);
            // await client.DeleteDatabaseAsync(database.SelfLink);
        }


        private async static Task CreateDatabase(DocumentClient client)
		{
			Console.WriteLine();
			Console.WriteLine(">>> Create Database <<<");

			var databaseDefinition = new Database { Id = "MyNewDatabase" };
			var result = await client.CreateDatabaseAsync(databaseDefinition);
			var database = result.Resource;
			Console.WriteLine(" Database Id: {0}; Rid: {1}", database.Id, database.ResourceId);
		}

		private async static Task DeleteDatabase(DocumentClient client)
		{
			Console.WriteLine();
			Console.WriteLine(">>> Delete Database <<<");

			Database database = client
				.CreateDatabaseQuery("SELECT * FROM c WHERE c.id = 'MyNewDatabase'")
				.AsEnumerable()
				.First();

			await client.DeleteDatabaseAsync(database.SelfLink);
		}


        private static void ViewCollections(DocumentClient client)
        {
            Console.WriteLine();
            Console.WriteLine(">>> View Collections in {0} <<<", _database.Id);

            var collections = client
                .CreateDocumentCollectionQuery(_database.CollectionsLink)
                .ToList();

            var i = 0;
            foreach (var collection in collections)
            {
                i++;
                Console.WriteLine();
                Console.WriteLine("Collection #{0}", i);
                ViewCollection(collection);
            }

            Console.WriteLine();
            Console.WriteLine("Total collections in database {0}: {1}", _database.Id, collections.Count);
        }

        private static void ViewCollection(DocumentCollection collection)
        {
            Console.WriteLine("    Collection ID: {0} ", collection.Id);
            Console.WriteLine("      Resource ID: {0} ", collection.ResourceId);
            Console.WriteLine("        Self Link: {0} ", collection.SelfLink);
            Console.WriteLine("   Documents Link: {0} ", collection.DocumentsLink);
            Console.WriteLine("        UDFs Link: {0} ", collection.UserDefinedFunctionsLink);
            Console.WriteLine(" StoredProcs Link: {0} ", collection.StoredProceduresLink);
            Console.WriteLine("    Triggers Link: {0} ", collection.TriggersLink);
            Console.WriteLine("        Timestamp: {0} ", collection.Timestamp);
        }
        private static void ViewCollection()
        {
            Console.WriteLine("    Collection ID: {0} ", _collection.Id);
            Console.WriteLine("      Resource ID: {0} ", _collection.ResourceId);
            Console.WriteLine("        Self Link: {0} ", _collection.SelfLink);
            Console.WriteLine("   Documents Link: {0} ", _collection.DocumentsLink);
            Console.WriteLine("        UDFs Link: {0} ", _collection.UserDefinedFunctionsLink);
            Console.WriteLine(" StoredProcs Link: {0} ", _collection.StoredProceduresLink);
            Console.WriteLine("    Triggers Link: {0} ", _collection.TriggersLink);
            Console.WriteLine("        Timestamp: {0} ", _collection.Timestamp);
        }

    }
}
