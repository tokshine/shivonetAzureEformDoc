﻿using System;

namespace Workwiz.ConsoleApplication.DocumentDb
{
    public class EFormDocument
    {
        public string FileUrl { get; set; }
        public string Filename { get; set; }
        public string FormId { get; set; }
        public string BusinessId { get; set; }

        public DateTime DateSubmitted { get; set; }

        public string FileSize  { get; set; }

        public string MimeType { get; set; }

        public string ExpiryUrl  { get; set; }
    }
}