﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Workwiz.Common.Azure.DocumentDB;

namespace Workwiz.Islington.DocumentStore.Infrastructure.Tests
{
    [TestClass]
    public class DocumentDbConnectionStringTests
    {
        [TestMethod]
        public void TestParsing()
        {
            Uri accountEndpoint = new Uri("https://workwizdev.documents.azure.com:443/");
            string dbName = "eform-documents";
            string collectionName = "businessratedocuments";
            string accessKey = "example5124354154==";

            string connectionString = $"AccountEndpoint={accountEndpoint};Database={dbName}; Collection={collectionName}; AccountKey={accessKey};";

            DocumentDbConnectionParameters parsedConnection = DocumentDbConnectionParameters.ParseConnectionString(connectionString);

            Assert.AreEqual(accountEndpoint, parsedConnection.EndPoint);
            Assert.AreEqual(dbName, parsedConnection.DatabaseName);
            Assert.AreEqual(collectionName, parsedConnection.CollectionName);
            Assert.AreEqual(accessKey, parsedConnection.AccountKey);
        }
    }
}
