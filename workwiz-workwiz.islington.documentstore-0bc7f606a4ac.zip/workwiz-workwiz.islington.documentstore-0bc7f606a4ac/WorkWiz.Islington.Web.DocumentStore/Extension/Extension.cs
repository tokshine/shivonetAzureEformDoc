﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace WorkWiz.Web.DocumentStore.Extension
{
    public static class Extension
    {


        public static MvcHtmlString UploadAction(
            this HtmlHelper html,
            object routeValues)
            
        {
           return html.Action(
                "Upload",
                "DocStorage",
                 routeValues
                );
        }

        public static MvcHtmlString DocumentListAction(
           this HtmlHelper html,
           object routeValues)

        {
            return html.Action(
                 "DocumentList",
                 "DocStorage",
                  routeValues
                 );
        }

    }
}