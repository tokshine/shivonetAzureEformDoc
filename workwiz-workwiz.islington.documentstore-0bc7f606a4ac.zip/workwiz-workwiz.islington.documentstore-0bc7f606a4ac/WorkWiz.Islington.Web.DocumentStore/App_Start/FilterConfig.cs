﻿using System.Web;
using System.Web.Mvc;

namespace Workwiz.Islington.DocumentStore.DevTestWeb
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
