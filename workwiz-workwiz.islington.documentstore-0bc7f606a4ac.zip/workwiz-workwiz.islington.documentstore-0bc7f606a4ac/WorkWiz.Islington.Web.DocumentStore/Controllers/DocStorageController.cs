﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Workwiz.Islington.DocumentStore.Shared;
using Workwiz.Islington.DocumentStore.Client;



namespace Workwiz.Islington.DocumentStore.DevTestWeb.Controllers
{
    public class DocStorageController : Controller
    {
        private IDocumentStoreHttpClient _client;

        public DocStorageController()
        {
            _client = new DocumentStoreHttpClient();
        }

        public ActionResult Upload(int? businessId, int? formId, string responseId,string topic,string userId)
        {
            var documentStorageModel = CreateDocumentStorageModel(formId, businessId, responseId, topic, userId);
            return PartialView(documentStorageModel);
        }

        public ActionResult DocumentList(int? businessId, int? formId, string responseId, string topic, string userId)
        {
            var documentStorageModel = CreateDocumentStorageModel(formId, businessId, responseId, topic, userId);
            return PartialView("_ViewDocumentList", documentStorageModel);
        }

        public ActionResult UploadDownloadTest()
        {
            return View();
        }

        public ActionResult UploadDownloadResponseTest()
        {
            return View();
        }
        public ActionResult UploadDownloadTopicTest()
        {
            return View();
        }

        public ActionResult UploadDownloadUserTest()
        {
            return View();
        }



        [System.Web.Mvc.HttpPost]
        public async Task<ActionResult> DeleteDocument(string guid, int formId, int businessId, string responseId,string topic,string userId)
        {
            await _client.DeleteDocument(guid);

            var documentStorageModel = CreateDocumentStorageModel(formId, businessId, responseId,topic, userId);
            return PartialView("_DocumentList", documentStorageModel);
        }


        [HttpPost]
        public ActionResult GenerateDocumentLink(string guid)
        { 
            var url= _client.GenerateDocumentLink(guid);            
            System.Threading.Thread.Sleep(5000);
            return Redirect(url);
        }

        public ActionResult Index()
        {
            return View();
        }


        [System.Web.Mvc.HttpPost]
        public async Task<ActionResult> UploadFile(int? formId, int? businessId, string responseId,string topic,string userId)
        {
            if (Request.Files.Count > 0)
            {
                var list = new List<DocumentDto>();
                for (int fileNum = 0; fileNum < Request.Files.Count; fileNum++)
                {
                    var file = Request.Files[fileNum];
                    if (file != null)
                    {
                        string fileName = Path.GetFileName(file.FileName);
                        if (
                            Request.Files[fileNum] != null &&
                            Request.Files[fileNum].ContentLength > 0)
                        {
                            var document = new DocumentDto();
                            document.FileName = fileName;
                            if (fileName != null)
                            {
                                string mimeType = MimeMapping.GetMimeMapping(fileName);
                                document.Stream = Request.Files[fileNum].InputStream;
                                document.FileType = mimeType;
                            }
                            list.Add(document);
                            await _client.CreateDocument(document, businessId, formId, responseId, topic, userId);
                            
                        }
                    }
                }
                //await _client.CreateDocuments(list, businessId, formId, responseId, topic, userId);

            }
            var documentStorageModel = CreateDocumentStorageModel(formId, businessId, responseId, topic, userId);
            return PartialView("_DocumentList", documentStorageModel);
        }

        private DocumentStorageDto CreateDocumentStorageModel(int? formId, int? businessId, string responseId,string topic, string userId)
        {
          
             if ((formId.HasValue && formId.Value > 0) && (businessId.HasValue && businessId.Value > 0))
            {
                var blobsList = _client.GetDocuments(businessId.GetValueOrDefault(), formId);
                var documentStorageModel = new DocumentStorageDto();
                documentStorageModel.FormId = formId;                
                documentStorageModel.BusinessId = businessId;
                documentStorageModel.CloudFiles = blobsList;

                return documentStorageModel;
            }

            if (!string.IsNullOrEmpty(responseId))
            {
                var blobsList = _client.GetDocuments(responseId);
                var documentStorageModel = new DocumentStorageDto();
                documentStorageModel.ResponseId = responseId;                
                documentStorageModel.CloudFiles = blobsList;

                return documentStorageModel;
            }

            if (!string.IsNullOrEmpty(topic) && (businessId.HasValue && businessId.Value > 0))
            {
                var blobsList = _client.GetDocuments(businessId.GetValueOrDefault(),topic);
                var documentStorageModel = new DocumentStorageDto();
                documentStorageModel.BusinessId = businessId;
                documentStorageModel.Topic = topic;
                documentStorageModel.CloudFiles = blobsList;

                return documentStorageModel;
            }


            if (!string.IsNullOrEmpty(userId))
            {
                var blobsList = _client.GetDocumentsByUserId(userId);
                var documentStorageModel = new DocumentStorageDto();
                documentStorageModel.UserId = userId;
                documentStorageModel.CloudFiles = blobsList;
                return documentStorageModel;
            }

            return new DocumentStorageDto() { CloudFiles = new List<DocumentDto>()};
        }

    }
}