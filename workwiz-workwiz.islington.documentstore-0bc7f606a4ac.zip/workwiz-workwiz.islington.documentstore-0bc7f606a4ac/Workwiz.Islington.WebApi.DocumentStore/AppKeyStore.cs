﻿using System;
using System.Configuration;

namespace Workwiz.Islington.DocumentStore.WebApi
{
    public class AppKeyStore : Workwiz.HMACSecurity.Server.IApiKeyStore
    {
        public string CreateApiKey(int strength)
        {
           throw new NotImplementedException( "Api Key creation not required at the moment");
        }
        public string GetApiKey(string appId)
        {
            var apiKey= ConfigurationManager.AppSettings["ApiKey"];
            return apiKey;
        }
    }

 
}
