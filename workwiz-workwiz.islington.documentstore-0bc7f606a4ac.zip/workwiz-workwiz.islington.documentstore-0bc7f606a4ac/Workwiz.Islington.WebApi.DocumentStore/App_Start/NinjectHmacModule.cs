using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ninject.Modules;
using Workwiz.HMACSecurity.Server;

namespace Workwiz.Islington.DocumentStore.WebApi.App_Start
{
    public class NinjectHmacModule : NinjectModule
    {
        public override void Load()
        {
            Kernel.Bind<IApiKeyStore>().To<AppKeyStore>();
        }
    }
}