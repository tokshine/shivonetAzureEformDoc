﻿using System.Web.Mvc;

namespace Workwiz.Islington.DocumentStore.WebApi.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            return RedirectToAction("Index","Help");
        }
    }
}
