﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;
using System.Configuration;
using Workwiz.Islington.DocumentStore.Shared;
using Workwiz.Islington.DocumentStore.Infrastructure;
using Microsoft.Azure.Documents;
using Workwiz.Islington.DocumentStore.WebApi.Filters;

namespace Workwiz.Islington.DocumentStore.WebApi.Controllers
{
    /// <summary>
    /// DocumentStore Api
    /// </summary>
    [DocumentStoreException]
    [RoutePrefix("api/documentstore")]
    public class ValuesController : ApiController
    {
        private IStorageService _storageService;
        private IMetadataService _metadataService;
        private static string FormPath = ConfigurationManager.AppSettings["FormPath"];

        public ValuesController(IStorageService storageService, IMetadataService metadataService)
        {
            _storageService = storageService;
            _metadataService = metadataService;
        }
            
        /// <summary>
        /// Get documents by businessId,formId is optional
        /// </summary>
        /// <param name="businessId"></param>
        /// <param name="formId"></param>
        [Route("documents/form/{businessId}/{formId}")]
        [HttpGet]
        [ResponseType(typeof(IEnumerable<DocumentDto>))]
        public IHttpActionResult GetDocumentMetadata(int businessId, int? formId)
        {
            var foundDocs = _metadataService.Search(new DocumentMetadataDto() { BusinessId = businessId.ToString(), FormId = formId?.ToString() });
            return GetDocuments(foundDocs);                     
        }

        /// <summary>
        /// Get document by blobIdentifierForDocument
        /// /// </summary>
        /// <param name="blobIdentifierForDocument"></param>
        [Route("documents/form/{blobIdentifierForDocument}")]
        [HttpGet]
        [ResponseType(typeof(DocumentDto))]
        public IHttpActionResult GetDocuments(string blobIdentifierForDocument)
        {
            var foundDoc = _metadataService.Search(new DocumentMetadataDto() { Guid = blobIdentifierForDocument }).FirstOrDefault();
            if (foundDoc != null)
            {
                var path = foundDoc.Path + "/" + foundDoc.Guid;
                return Ok(GetFullDocument(path, foundDoc));
            }
            return NotFound();
        }


        /// <summary>
        /// Get documents by businessId,topic - Topic example could be 'Business rates'
        /// </summary>
        /// <param name="businessId"></param>
        /// <param name="topic">document category</param>
        [Route("documents/topic/{businessId}/{topic}")]
        [HttpGet]
        [ResponseType(typeof(IEnumerable<DocumentDto>))]
        public IHttpActionResult GetDocumentMetadata(int businessId, string topic)
        {
            var foundDocs = _metadataService.Search(new DocumentMetadataDto() { BusinessId = businessId.ToString(), Topic = topic });
            return GetDocuments(foundDocs);
        }

        /// <summary>
        /// Get documents by responseId
        /// </summary>
        /// <param name="responseId">Form submissionId</param>
        [Route("documents/response/{responseId}")]
        [HttpGet]
        [ResponseType(typeof(List<DocumentDto>))]
        public  IHttpActionResult GetDocumentMetadata(string responseId)
        {
            var foundDocs = _metadataService.Search(new DocumentMetadataDto() { ResponseId = responseId });

            return GetDocuments(foundDocs);

        }


        /// <summary>
        /// Get documents by userId
        /// </summary>
        /// <param name="userId"></param>
        [Route("documents/user/{userId}")]
        [HttpGet]
        [ResponseType(typeof(IEnumerable<DocumentDto>))]
        public IHttpActionResult GetDocumentMetadataByUserId(string userId)
        {
            var foundDocs = _metadataService.Search(new DocumentMetadataDto() { UserId = userId });

            return GetDocuments(foundDocs);
        }


        /// <summary>
        /// Get download link by documentId
        /// </summary>
        /// <param name="guid">document Id</param>
        [Route("{guid}")]
        [HttpPost]
        [ResponseType(typeof(string))]
        public IHttpActionResult GenerateDocumentLink(string guid)
        {
            var foundDocs = _metadataService.Search(new DocumentMetadataDto() { Guid = guid });

            var foundDoc = foundDocs.FirstOrDefault();

            if (foundDoc != null)
            {

                string path;
                try
                {
                    path = foundDoc.Path + "/" + foundDoc.Guid;
                   return Ok(_storageService.GenerateDocumentLink(path));
                }
                catch (DocumentClientException documentClientException)
                {

                    throw;
                }         
            }

            return NotFound();
        }

        /// <summary>
        /// Delete document metadata by documentId
        /// </summary>
        /// <param name="guid">document Id</param>
        [Route("documents/{guid}")]
        [HttpDelete]
        public IHttpActionResult DeleteDocumentMetadata(string guid)
        {
            var documentDto = new DocumentMetadataDto()
            {
                Guid = guid
            };
            var foundDocs = _metadataService.Search(documentDto);          
            foreach (var foundDoc in foundDocs)
            {

                 _metadataService.DeleteDocumentMetadata(foundDoc.Guid);
                 var fullPath = string.Format("{0}/{1}", foundDoc.Path, foundDoc.Guid);
                _storageService.DeleteDocument(fullPath);
            }

            var anyDocRef = _metadataService.Search(documentDto);
            if (anyDocRef == null)
            {
                return StatusCode(HttpStatusCode.NoContent);
            }
            return InternalServerError();
        }

        /// <summary>
        /// Upload collection of documents for a form
        /// </summary>
        /// <param name="documents">collection of documents with associated metadata to save</param>
        [HttpPost]
        [Route("documents")]
        public IHttpActionResult PostDocument(IEnumerable<DocumentContainerDto> documents)
        {
            if (documents == null) return InternalServerError();
            foreach (var item in documents)
            {
                SaveDocument(item);
            }
            return Ok();
        }

        /// <summary>
        /// Upload document for a form
        /// </summary>
        /// <param name="container">document with associated metadata to save</param>
        [Route("document")]
        [ResponseType(typeof(string))]
        [HttpPost]
        public IHttpActionResult Post(DocumentContainerDto container)
        {

            if (container?.Document == null) return InternalServerError();
            var documentId = SaveDocument(container);
            return Ok(documentId);
        }
        
      
        private DocumentDto GetFullDocument(string path, dynamic foundDoc)
        {
            var storageDoc = _storageService.GetDocument(path);
            storageDoc.Guid = foundDoc.Guid;          
            storageDoc.FileName = foundDoc.Filename;
            storageDoc.FileType = foundDoc.MimeType;
            return storageDoc;
        }


        private IHttpActionResult GetDocuments(IEnumerable<dynamic> foundDocs)
        {

            var returnDocs = new List<DocumentDto>();
            foreach (var foundDoc in foundDocs)
            {
                string path;
                try
                {
                    path = foundDoc.Path + "/" + foundDoc.Guid;
                    returnDocs.Add(GetFullDocument(path, foundDoc));
                }
                catch (DocumentClientException documentClientException)
                {
                    throw;
                }

            }


            if (returnDocs == null)
            {
                return NotFound();
            }
            return Ok(returnDocs);    


        }

        private string SaveDocument(DocumentContainerDto container)
        {
            
            var metadata = new DocumentMetadataDto()
            {
                Guid = Guid.NewGuid().ToString(),
                FormId = container.Metadata.FormId.ToString(),
                BusinessId = container.Metadata.BusinessId.ToString(),
                ResponseId = container.Metadata.ResponseId,
                UserId = container.Metadata.UserId,
                Path = FormPath + container.Metadata.FormId.ToString(),
                Topic = container.Metadata.Topic,
                Filename = container.Document.FileName,
                MimeType = container.Document.FileType,
                DateSubmitted = DateTime.Now
            };
            _metadataService.CreateDocumentMetadata(metadata);
            container.Document.Guid = metadata.Guid;
            container.Document.Path = metadata.Path;
            container.Document.Stream = new MemoryStream(Convert.FromBase64String(container.Document.Base64String));

            _storageService.UploadDocument(container.Document);

            return metadata.Guid;
        }
    }
}
