namespace Workwiz.Islington.DocumentStore.WebApi.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}