﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;
using Microsoft.Owin.Logging;
using Workwiz.Islington.DocumentStore.Shared.Exceptions;

namespace Workwiz.Islington.DocumentStore.WebApi.Filters
{
    public  class DocumentStoreExceptionAttribute : ExceptionFilterAttribute
    {

       
            public override void OnException(HttpActionExecutedContext actionExecutedContext)
            {
                if (actionExecutedContext.Exception is DocumentStoreException)
                {
                    var docStoreException = actionExecutedContext.Exception as DocumentStoreException;
                    actionExecutedContext.Response = actionExecutedContext.Request.CreateErrorResponse(docStoreException.Status,
                        docStoreException.Message);

                    var logger = actionExecutedContext.Request.GetOwinContext().Get<ILogger>("server.Logger");
                    logger.WriteError(docStoreException.Message, docStoreException);
                }
            }
        
    }
}
