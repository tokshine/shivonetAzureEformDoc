﻿using System.Collections.Generic;

namespace Workwiz.Islington.DocumentStore.Shared
{
    public class DocumentStorageDto
    {
        public int? FormId { get; set; }
        public int? BusinessId { get; set; }

        public string Topic { get; set; }

        public string UserId { get; set; }

        public string ResponseId { get; set; }
        public IEnumerable<DocumentDto> CloudFiles { get; set; }
    }
}