﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Workwiz.Islington.DocumentStore.Shared
{
    
    public class DocumentDto
    {
        public string FileName { get; set; } // Properties.ContentDisposition
        public string FileType { get; set; } // Properties.ContentType
        public string Path { get; set; } // Parent
        public string Guid { get; set; } // Name
        [JsonIgnore]
        public Stream Stream { get; set; }
        public string  Base64String { get; set; }
    }

}