﻿using System.Collections.Generic;
using System.Dynamic;
using Newtonsoft.Json.Linq;

namespace Workwiz.Islington.DocumentStore.Shared
{
    public class DocumentContainerDto
    {
        public DocumentDto Document { get; set; }
        public dynamic Metadata { get; set; }
    }
}