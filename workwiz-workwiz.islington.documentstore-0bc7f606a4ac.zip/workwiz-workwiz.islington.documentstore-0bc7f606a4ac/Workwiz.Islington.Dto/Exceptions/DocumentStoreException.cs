﻿using System;
using System.Net;

namespace Workwiz.Islington.DocumentStore.Shared.Exceptions
{
    public class DocumentStoreException :Exception
    {

        public HttpStatusCode Status { get; set; }

        public DocumentStoreException(HttpStatusCode status, string message) : base(message)
        {
            Status = status;
        }
    }
}
