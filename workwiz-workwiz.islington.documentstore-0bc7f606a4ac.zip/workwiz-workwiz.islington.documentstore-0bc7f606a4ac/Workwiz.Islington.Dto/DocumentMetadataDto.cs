﻿using System;
using Newtonsoft.Json;

namespace Workwiz.Islington.DocumentStore.Shared
{
    public class DocumentMetadataDto
    {
       
        public string Filename { get; set; }
        public string FormId { get; set; }
        public string BusinessId { get; set; }

        public string UserId { get; set; }
        public string Path { get; set; }

        public string Topic { get; set; }
        public string Guid { get; set; }
        public string ResponseId { get; set; }

        public DateTime DateSubmitted { get; set; }

        public string FileSize { get; set; }

        public string MimeType { get; set; }

        public string ExpiryUrl { get; set; }

        public bool IsProcessed { get; set; }
    }
}  