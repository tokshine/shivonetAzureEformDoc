﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;


namespace Workwiz.Islington.DocumentStore.Client
{
    public class ApiDeadlockWorkaround
    {

        public static TResult CallWithSafeWrapperForAsync<TResult>(Func<TResult> actionToWrap)
        {
            System.Web.HttpContext currentContext = System.Web.HttpContext.Current;
            return Task.Factory.StartNew<TResult>(() =>
            {
                System.Web.HttpContext.Current = currentContext;
                return actionToWrap();
            }, TaskCreationOptions.LongRunning).Result;
        }
    }
}