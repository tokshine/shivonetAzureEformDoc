using System.Collections.Generic;
using System.Threading.Tasks;
using Workwiz.Islington.DocumentStore.Shared;

namespace Workwiz.Islington.DocumentStore.Client
{
    public interface IDocumentStoreHttpClient
    {
        IEnumerable<DocumentDto> GetDocuments(int businessId, int? formId);

        DocumentDto GetDocument(string blobIdentifierForDocument);

        IEnumerable<DocumentDto> GetDocuments(string responseId);       


        IEnumerable<DocumentDto> GetDocumentsByUserId(string userId);

        IEnumerable<DocumentDto> GetDocuments(int businessId,string topic);
        Task<string> CreateDocument(DocumentDto document, int? businessId, int? formId, string responseId,string topic,string userId);

        Task CreateDocuments(IEnumerable<DocumentDto> document, int? businessId, int? formId, string responseId, string topic, string userId);
        Task DeleteDocument(string guid);

        string GenerateDocumentLink(string guid);
    }
}