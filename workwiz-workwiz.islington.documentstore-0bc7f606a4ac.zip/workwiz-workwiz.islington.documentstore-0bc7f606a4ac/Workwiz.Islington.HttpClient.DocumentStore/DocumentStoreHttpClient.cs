﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Web;
using System.Net.Http.Formatting;
using Newtonsoft.Json.Linq;
using Workwiz.Islington.DocumentStore.Shared;
using Workwiz.HMACSecurity.Client;


namespace Workwiz.Islington.DocumentStore.Client
{
    public class DocumentStoreHttpClient : IDocumentStoreHttpClient
    {
        private readonly System.Net.Http.HttpClient _client;
        public DocumentStoreHttpClient()
        {
            var appKeys = ConfigurationManager.AppSettings;
            _client = new HttpClient(new HMACDelegatingHandler(appKeys["apiKey"], appKeys["appId"]));
            _client.BaseAddress = new Uri(appKeys["DocumentStoreRestServiceAddress"]);
            _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public IEnumerable<DocumentDto> GetDocuments(int businessId, int? formId)
        {

            return ApiDeadlockWorkaround.CallWithSafeWrapperForAsync<IEnumerable<DocumentDto>>(() =>
            {
                var url = $"api/documentstore/documents/form/{businessId}/{formId}";
                var response = _client.GetAsync(url);

                var message = response.Result.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<IEnumerable<DocumentDto>>(message);
                return result;
            });

        }

        public DocumentDto GetDocument(string blobIdentifierForDocument)
        {

            return ApiDeadlockWorkaround.CallWithSafeWrapperForAsync<DocumentDto>(() =>
            {
                var url = $"api/documentstore/documents/form/{blobIdentifierForDocument}";
                var response = _client.GetAsync(url);

                var message = response.Result.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<DocumentDto>(message);
                return result;
            });

        }
        public IEnumerable<DocumentDto> GetDocuments(int businessId, string topic)
        {
            return ApiDeadlockWorkaround.CallWithSafeWrapperForAsync<IEnumerable<DocumentDto>>(() =>
            {
                var url = $"api/documentstore/documents/topic/{businessId}/{topic}";
                var response = _client.GetAsync(url);

                var message = response.Result.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<IEnumerable<DocumentDto>>(message);
                return result;
            });
        }



        public IEnumerable<DocumentDto> GetDocuments(string responseId)
        {
            return ApiDeadlockWorkaround.CallWithSafeWrapperForAsync<IEnumerable<DocumentDto>>(() =>
            {
                var url = $"api/documentstore/documents/response/{responseId}";
                var response = _client.GetAsync(url);

                var message = response.Result.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<IEnumerable<DocumentDto>>(message);
                return result;
            });
        }

        public IEnumerable<DocumentDto> GetDocumentsByUserId(string userId)
        {
            return ApiDeadlockWorkaround.CallWithSafeWrapperForAsync<IEnumerable<DocumentDto>>(() =>
            {
                var url = $"api/documentstore/documents/user/{userId}";
                var response = _client.GetAsync(url);

                var message = response.Result.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<IEnumerable<DocumentDto>>(message);
                return result;
            });
        }



        public string GenerateDocumentLink(string guid)
        {
            return ApiDeadlockWorkaround.CallWithSafeWrapperForAsync<string>(() =>
            {
                var url = $"api/documentstore/{guid}";
                var response = _client.PostAsJsonAsync(url,guid);

                var message = response.Result.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<String>(message);
                return result;
            });
        }

        public async Task<string> CreateDocument(DocumentDto document, int? businessId, int? formId, string responseId, string topic, string userId)
        {

            var url = "api/documentstore/document";

            ProcessDocument(document);

            var container = new DocumentContainerDto();
            container.Document = document;
            container.Metadata = new JObject();
            container.Metadata.BusinessId = businessId;
            container.Metadata.FormId = formId;
            container.Metadata.ResponseId = responseId;
            container.Metadata.Topic = topic;
            container.Metadata.UserId = userId;
            var response = await _client.PostAsJsonAsync(url, container);
            var responsestring = response.Content.ReadAsStringAsync().Result;
            return JsonConvert.DeserializeObject<string>(responsestring);
        }


        public async Task CreateDocuments(IEnumerable<DocumentDto> documents, int? businessId, int? formId, string responseId, string topic, string userId)
        {

            var url = "api/documentstore/documents";
            var documentContainers = new List<DocumentContainerDto>();
            foreach (var document in documents)
            {
                ProcessDocument(document);
                var container = new DocumentContainerDto();
                container.Document = document;
                container.Metadata = new JObject();
                container.Metadata.BusinessId = businessId;
                container.Metadata.FormId = formId;
                container.Metadata.ResponseId = responseId;
                container.Metadata.Topic = topic;
                container.Metadata.UserId = userId;
                documentContainers.Add(container);
            }
            

           
            await _client.PostAsJsonAsync(url, documentContainers);
        }

        public async Task DeleteDocument(string guid)
        {
            var url = $"api/documentstore/documents/{guid}";
            await _client.DeleteAsync(url);
        }

        private void ProcessDocument(DocumentDto document)
        {
            var bytes = document.Stream.ReadAllBytes();
            var base64String = Convert.ToBase64String(bytes);
            document.Base64String = base64String;
            document.Stream = null;
        }

        private string GetFileName(string filename)
        {
            Uri uri = new Uri(filename);
            string fileName = System.IO.Path.GetFileName(uri.LocalPath);
            return fileName;
        }
    }
}