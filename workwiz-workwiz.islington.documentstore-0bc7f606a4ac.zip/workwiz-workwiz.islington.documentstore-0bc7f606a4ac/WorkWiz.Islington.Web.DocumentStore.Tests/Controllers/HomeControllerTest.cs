﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Workwiz.Lbi.DocumentStore.DevTestWeb;
using Workwiz.Lbi.DocumentStore.DevTestWeb.Controllers;

namespace Workwiz.Lbi.DocumentStore.DevTestWeb.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            DocStorageController controller = new DocStorageController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
        

        
    }
}
