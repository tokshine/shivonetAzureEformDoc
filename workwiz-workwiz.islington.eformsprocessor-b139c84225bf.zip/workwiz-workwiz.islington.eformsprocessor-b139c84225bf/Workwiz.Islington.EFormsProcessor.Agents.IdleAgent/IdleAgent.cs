﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using System.IO;
using Workwiz.Islington.EFormsProcessor.Agents.Shared;
using System.Threading;
namespace Workwiz.Islington.EFormsProcessor.Agents.IdleAgent
{
    public class IdleAgent : BaseAgent
    {
        public IdleAgent() : base() { SubscriptionName = "IdleAgentSub"; }
        
        public override string AgentName
        {
            get
            {
                return "IdleAgent";
            }
        }

        //ManualResetEvent _completedEvent = new ManualResetEvent(false);
        public override Task Start()
        {
            Logger.Info("Initalizing agent ..");
            base.Start();
            if (HasInitialized)
            {
                try
                {
                    //TODO refactory the steps below and create a method in base class for that.
                    //create topic
                    if (!_namespaceManager.TopicExists(InfrastructureSettings.DoNothingQueueTopic))
                    {
                        _namespaceManager.CreateTopic(InfrastructureSettings.DoNothingQueueTopic);
                    }
                    //create subscription
                    if (!_namespaceManager.SubscriptionExists(InfrastructureSettings.DoNothingQueueTopic, SubscriptionName))
                    {
                        _namespaceManager.CreateSubscription(InfrastructureSettings.DoNothingQueueTopic, SubscriptionName);
                    }

                    _subscriptionClient = SubscriptionClient.CreateFromConnectionString(InfrastructureSettings.ServiceBusConnection,
                   InfrastructureSettings.DoNothingQueueTopic, SubscriptionName);

                    _subscriptionClient.OnMessage(m => Process(m), new OnMessageOptions() { AutoComplete = false, AutoRenewTimeout = TimeSpan.FromMinutes(1) });
                    Logger.Info("Agent initalized successfully");
                    return Task.FromResult(true);
                }
                catch (Exception)
                {
                    //TODO log
                    HasInitialized = false;
                    throw;
                }


            }
            Logger.Error("Unable to initialize Agent");
            return Task.FromResult(false);
        }
        public override Task<AgentProcessingResult> Process(BrokeredMessage message)
        {
            //System.Diagnostics.Trace.WriteLine("this is a message from idle agent");
            if (!File.Exists("c:\\temp\\IdleAgent.txt"))
            {
                File.Create("c:\\temp\\IdleAgent.txt");
            }

            return Task.FromResult(new AgentProcessingResult() { IsSuccessful = true });
        }

        public override Task Stop()
        {
            if (HasInitialized)
            {
                if (_subscriptionClient != null)
                {
                    _subscriptionClient.Close();
                }
            }
            return Task.FromResult(true);
        }
    }
}
