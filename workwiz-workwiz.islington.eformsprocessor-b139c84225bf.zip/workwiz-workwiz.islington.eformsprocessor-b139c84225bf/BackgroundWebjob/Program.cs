﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.ServiceBus;
using Settings = Workwiz.Islington.EFormsProcessor.Shared.Properties.Settings;

namespace BackgroundWebjob
{
    class Program
    {
        static void Main(string[] args)
        {
            string serviceBusConnectionString = Settings.Default.ServiceBusConnection;

            JobHostConfiguration config = new JobHostConfiguration();
            ServiceBusConfiguration serviceBusConfig = new ServiceBusConfiguration
            {
                ConnectionString = serviceBusConnectionString
            };
            config.UseServiceBus(serviceBusConfig);

            JobHost host = new JobHost(config);
            host.RunAndBlock();
        }
    }
}
