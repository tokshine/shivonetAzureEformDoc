﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.ServiceBus.Messaging;
using Workwiz.Islington.EFormsProcessor.Agents.PdfAgent;

namespace BackgroundWebjob
{
    public class AgentRunners
    {
        private static readonly string pdfTopic =
            Workwiz.Islington.EFormsProcessor.Shared.Properties.Settings.Default.PdfQueueTopic;
    
    

    public static void RunPdfAgent([ServiceBusTrigger("generatepdf", "PdfAgentSub")] BrokeredMessage message, TextWriter log)
        {
            var agent = new PdfAgent();
            log.Write($"Processing PDF message {message.Properties["FormId"]}");
            try
            {
                agent.Process(message);
            }
            catch (Exception ex)
            {
                log.Write(ex.Message);
            }
        }
    }

}
