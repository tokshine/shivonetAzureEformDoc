﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Workwiz.Islington.EFormsProcessor.Services;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Workwiz.Common.Azure.DocumentDB;

namespace Workwiz.Islington.EFormsProcessor.Tests.Services
{
    [TestClass]
    public class WorkflowServiceTests
    {
        DocumentDbConnectionFactory WfDocumentDbConnectionFactory
        {
            get
            {
                if (_wfDocumentDbConnectionFactory == null)
                    _wfDocumentDbConnectionFactory = new DocumentDbConnectionFactory("WorkflowDb", Microsoft.Azure.Documents.ConsistencyLevel.Session);
                return _wfDocumentDbConnectionFactory;
            }
        }
        DocumentDbConnectionFactory _wfDocumentDbConnectionFactory = null;
        IWorkflowService srv = null;


        [TestInitialize]
        public void Init()
        {
            srv = new WorkflowService(WfDocumentDbConnectionFactory);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public void TestServiceInit()
        {
            Assert.IsNotNull(srv);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowCreate()
        {
            var doc = new Workflow() { WorkflowType = "1" };
            doc = await srv.CreateAsync(doc);
            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);
        }


        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowUpdate()
        {
            var Workflow = new Workflow();
            Workflow.WorkflowType = "3";
            Workflow.WorkflowId = "bc1b5484-bbc0-4628-949a-e2167c32afeb";
            await srv.UpdateAsync(Workflow);

        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowDelete()
        {
            var doc = new Workflow() { WorkflowType = "1" };
            doc = await srv.CreateAsync(doc);
            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);

            await srv.DeleteAsync(doc.WorkflowId);
            Assert.IsNull(srv.GetAsync(doc.WorkflowId).Result);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public void TestWorkflowGet()
        {
            string id = "80cf7c73-3379-4a3f-90a2-84c531594baa";
            Assert.IsNotNull(srv.GetAsync(id).Result);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowGetNextStepSuccess()
        {
            var Workflow = new Workflow();
            Workflow.WorkflowType = "1";
            var steps = new List<WorkflowStep>();
            steps.Add(new WorkflowStep() { Name = "s1", Number = 1 });
            steps.Add(new WorkflowStep() { Name = "s2", Number = 2 });
            steps.Add(new WorkflowStep() { Name = "s3", Number = 3 });
            Workflow.Steps = steps;
            var doc = await srv.CreateAsync(Workflow);

            var nextStep = await srv.GetNextStepAsync(doc.WorkflowId, steps[0].Number);
            var nextStep2 = await srv.GetNextStepAsync(doc.WorkflowId, steps[1].Number);
            var nextStep3 = await srv.GetNextStepAsync(doc.WorkflowId, steps[2].Number);

            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);
            Assert.IsNotNull(nextStep);
            Assert.IsTrue(nextStep.Number == 2);
            Assert.IsNotNull(nextStep2);
            Assert.IsTrue(nextStep2.Number == 3);
            Assert.IsNotNull(nextStep3);
            Assert.IsTrue(nextStep3.Number == 3); // remains at the current step
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowGetNextStepInvalid()
        {
            var Workflow = new Workflow();
            Workflow.WorkflowType = "1";
            var steps = new List<WorkflowStep>();
            steps.Add(new WorkflowStep() { Name = "s1", Number = 1 });
            Workflow.Steps = steps;
            var doc = await srv.CreateAsync(Workflow);

            var nextStep = await srv.GetNextStepAsync(doc.WorkflowId, 4);

            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);
            Assert.IsNull(nextStep); // no next step found
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowGetCurrentStepSuccess()
        {
            var Workflow = new Workflow();
            Workflow.WorkflowType = "1";
            var steps = new List<WorkflowStep>();
            steps.Add(new WorkflowStep() { Name = "s1", Number = 1 });
            Workflow.Steps = steps;
            var doc = await srv.CreateAsync(Workflow);

            var currentStep = await srv.GetCurrentStepNumberAsync(doc.WorkflowId, steps[0].Number);

            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);
            Assert.IsNotNull(currentStep);
            Assert.IsTrue(currentStep.Number == 1);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowGetCurrentStepInvalid()
        {
            var Workflow = new Workflow();
            Workflow.WorkflowType = "1";
            var steps = new List<WorkflowStep>();
            steps.Add(new WorkflowStep() { Name = "s1", Number = 1 });
            Workflow.Steps = steps;
            var doc = await srv.CreateAsync(Workflow);

            var currentStep = await srv.GetCurrentStepNumberAsync(doc.WorkflowId, 3);

            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);
            Assert.IsNull(currentStep);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowGetPreviousStepSuccess()
        {
            var Workflow = new Workflow();
            Workflow.WorkflowType = "1";
            var steps = new List<WorkflowStep>();
            steps.Add(new WorkflowStep() { Name = "s1", Number = 1 });
            steps.Add(new WorkflowStep() { Name = "s2", Number = 2 });
            steps.Add(new WorkflowStep() { Name = "s3", Number = 3 });
            Workflow.Steps = steps;
            var doc = await srv.CreateAsync(Workflow);

            var prevStep = await srv.GetPreviousStepAsync(doc.WorkflowId, steps[2].Number);
            var prevStep2 = await srv.GetPreviousStepAsync(doc.WorkflowId, steps[1].Number);
            var prevStep3 = await srv.GetPreviousStepAsync(doc.WorkflowId, steps[0].Number);

            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);
            Assert.IsNotNull(prevStep);
            Assert.IsTrue(prevStep.Number == 2);
            Assert.IsNotNull(prevStep2);
            Assert.IsTrue(prevStep2.Number == 1);
            Assert.IsNotNull(prevStep3);
            Assert.IsTrue(prevStep3.Number == 1); // remains at the current step
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestWorkflowGetPreviousStepInvalid()
        {
            var Workflow = new Workflow();
            Workflow.WorkflowType = "1";
            var steps = new List<WorkflowStep>();
            steps.Add(new WorkflowStep() { Name = "s1", Number = 1 });
            Workflow.Steps = steps;
            var doc = await srv.CreateAsync(Workflow);

            var prevStep = await srv.GetPreviousStepAsync(doc.WorkflowId, 4);

            Assert.IsNotNull(doc.WorkflowId);
            Assert.IsTrue(doc.WorkflowId.Trim().Length > 0);
            Assert.IsNull(prevStep); // no next step found
        }
    }
}
