﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Workwiz.Islington.EFormsProcessor.Services;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;

namespace Workwiz.Islington.EFormsProcessor.Tests.Services
{
    [TestClass]
    public class QueueServiceTests
    {
        IQueueService srv = null;

        [TestInitialize]
        public  void Init() { srv = new QueueService();}

        [TestCategory("Integration")]
        [TestMethod]
        public void TestServiceInit()
        {
            Assert.IsNotNull(srv);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public void TestCreateMessage()
        {
            //srv.CreateQueueItem("step1","form1");
        }


    }
}
