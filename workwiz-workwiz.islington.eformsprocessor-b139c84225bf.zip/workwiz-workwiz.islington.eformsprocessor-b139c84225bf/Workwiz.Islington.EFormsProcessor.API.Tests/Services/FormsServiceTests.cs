﻿using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Workwiz.Islington.EFormsProcessor.Services;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Workwiz.Common.Azure.DocumentDB;


namespace Workwiz.Islington.EFormsProcessor.Tests.Services
{
    [TestClass]
    public class FormsServiceTests
    {
        DocumentDbConnectionFactory WfDocumentDbConnectionFactory
        {
            get
            {
                if (_wfDocumentDbConnectionFactory == null)
                    _wfDocumentDbConnectionFactory = new DocumentDbConnectionFactory("FormsDb", Microsoft.Azure.Documents.ConsistencyLevel.Session);
                return _wfDocumentDbConnectionFactory;
            }
        }
        DocumentDbConnectionFactory _wfDocumentDbConnectionFactory = null;
        IFormService srv = null;

        [TestInitialize]
        public void Init()
        {
            srv = new FormsService(WfDocumentDbConnectionFactory);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public void TestServiceInit()
        {
            Assert.IsNotNull(srv);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestFormCreate()
        {
            var doc = new Form() { FormTemplateId = "1" };
            doc = await srv.CreateAsync(doc);
            Assert.IsNotNull(doc.SubmittedFormId);
            Assert.IsTrue(doc.SubmittedFormId.Trim().Length > 0);
        }


        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestFormUpdate()
        {
            var doc = new Form() { FormTemplateId = "1" };
            doc = await srv.CreateAsync(doc);
            Assert.IsNotNull(doc.SubmittedFormId);
            Assert.IsTrue(doc.SubmittedFormId.Trim().Length > 0);

            var form = new Form();
            form.FormTemplateId = "3";
            form.SubmittedFormId = doc.SubmittedFormId;
            await srv.UpdateAsync(form);

        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestFormDelete()
        {
            var doc = new Form() { FormTemplateId = "1" };
            doc = await srv.CreateAsync(doc);
            Assert.IsNotNull(doc.SubmittedFormId);
            Assert.IsTrue(doc.SubmittedFormId.Trim().Length > 0);

            string id = doc.SubmittedFormId;
            await srv.DeleteAsync(doc.SubmittedFormId);
            Assert.IsNull(srv.GetAsync(doc.SubmittedFormId).Result);
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task TestFormGet()
        {
            var doc = new Form() { FormTemplateId = "1" };
            doc = await srv.CreateAsync(doc);
            Assert.IsNotNull(doc.SubmittedFormId);
            Assert.IsTrue(doc.SubmittedFormId.Trim().Length > 0);

            Assert.IsNotNull(srv.GetAsync(doc.SubmittedFormId).Result);
        }

    }
}
