﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;
using Castle.Components.DictionaryAdapter;
using Marvin.JsonPatch;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Workwiz.Islington.EFormsProcessor.API.Controllers;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents;
using Workwiz.Islington.EFormsProcessor.Shared.Enums;

namespace Workwiz.Islington.EFormsProcessor.Tests.ApiControllers
{
    [TestClass]
    public class FormsControllerTests
    {
        private Mock<IFormService> _mockFormService;
        private Mock<IWorkflowService> _mockWorkflowService;
        private Mock<IFormTemplateService> _mockTemplateService;
        private Mock<IQueueService> _mockQueueService;

        [TestInitialize]
        public void Initialize()
        {
            _mockFormService = new Mock<IFormService>();
            _mockWorkflowService = new Mock<IWorkflowService>();
            _mockTemplateService = new Mock<IFormTemplateService>();
            _mockQueueService = new Mock<IQueueService>();
        }

        [TestMethod]
        public async Task GetFormByIdReturnsCorrectTypeAndStatusOnFound()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            IHttpActionResult actionResult = await controller.GetFormByIdAsync("form1");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(OkNegotiatedContentResult<Form>));
            var contentResult = actionResult as OkNegotiatedContentResult<Form>;
            Assert.IsInstanceOfType(contentResult?.Content, typeof(Form));
        }

        [TestMethod]
        public async Task GetFormByIdReturnsCorrectTypeAndStatusOnNotFound()
        {
            // Arrange
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            IHttpActionResult actionResult = await controller.GetFormByIdAsync("form1");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task CreateFormReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.CreateAsync(It.IsAny<Form>())).Returns<Form>(x => Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = x.FormTemplateId,
                Workflow = x.Workflow,
                Response = x.Response
            }));
            _mockTemplateService.Setup(x => x.GetByFormNameAsync(It.IsAny<string>()))
                .Returns(
                    Task.FromResult(new List<FormTemplate>() { new FormTemplate()
                    {
                        TemplateId = "teamplateId",
                        FormType = "GeneralEnquiry",
                        WorkflowType = "GeneralEnquiry"
                    }}));
            _mockWorkflowService.Setup(x => x.GetByTypeAsync(It.IsAny<string>()))
                .Returns(
                    Task.FromResult(new Workflow()
                    {
                        WorkflowId = "workflowId",
                        WorkflowType = "GeneralEnquiry",
                        Steps = new List<WorkflowStep>() { new WorkflowStep() { Number = 1, Name = "PageOne" } }
                    }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            IHttpActionResult actionResult = await controller.CreateAsync(new Form()
            {
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" },
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() }
            });

            // Assert
            _mockTemplateService.Verify(x => x.GetByFormNameAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetByTypeAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(CreatedAtRouteNegotiatedContentResult<Form>));
            var contentResult = actionResult as CreatedAtRouteNegotiatedContentResult<Form>;
            Assert.IsFalse(string.IsNullOrEmpty(contentResult?.RouteName));
            Assert.IsFalse(string.IsNullOrEmpty(contentResult?.Content.SubmittedFormId));
            Assert.IsInstanceOfType(contentResult?.Content, typeof(Form));
        }

        [TestMethod]
        public async Task CreateFormReturnsCorrectTypeAndStatusOnNullTemplate()
        {
            // Arrange
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object); ;

            // Act
            IHttpActionResult actionResult = await controller.CreateAsync(new Form()
            {
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" },
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() }
            });

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task CreateFormReturnsCorrectTypeAndStatusOnNullWorkflow()
        {
            // Arrange
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object); ;

            // Act
            IHttpActionResult actionResult = await controller.CreateAsync(new Form()
            {
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" },
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() }
            });

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task CreateFormReturnsCorrectTypeAndStatusOnFailure()
        {
            // Arrange
            _mockTemplateService.Setup(x => x.GetByFormNameAsync(It.IsAny<string>()))
                .Returns(
                    Task.FromResult(new List<FormTemplate>() { new FormTemplate()
                    {
                        TemplateId = "teamplateId",
                        FormType = "GeneralEnquiry",
                        WorkflowType = "GeneralEnquiry"
                    }}));
            _mockWorkflowService.Setup(x => x.GetByTypeAsync(It.IsAny<string>()))
                .Returns(
                    Task.FromResult(new Workflow()
                    {
                        WorkflowId = "workflowId",
                        WorkflowType = "GeneralEnquiry",
                        Steps = new List<WorkflowStep>() { new WorkflowStep() { Number = 1, Name = "PageOne" } }
                    }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            IHttpActionResult actionResult = await controller.CreateAsync(new Form()
            {
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" },
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() }
            });

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(InternalServerErrorResult));
        }

        [TestMethod]
        public async Task UpdateResponseWithoutWorkflowReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" }
            }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Form>));
            var contentResult = actionResult as NegotiatedContentResult<Form>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
        }

        [TestMethod]
        public async Task UpdateResponseWithoutWorkflowReturnsCorrectTypeAndStatusOnFormNotFound()
        {
            // Arrange

            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseAsync("formId", patchDoc);

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task UpdateResponseWithWorkflowReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" }
            }));
            _mockWorkflowService.Setup(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(new WorkflowStep() { Number = 2, Name = "GetFINumber", IsQueueable = true }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            // _mockQueueService.Verify(x => x.CreateQueueItem(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Form>));
            var contentResult = actionResult as NegotiatedContentResult<Form>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
        }

        public async Task UpdateResponseWithWorkflowDoesNotQueueIfStepNotQueueable()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            _mockWorkflowService.Setup(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(new WorkflowStep() { Number = 2, Name = "GetFINumber", IsQueueable = false }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object); ;

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            //_mockQueueService.Verify(x => x.CreateQueueItem(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [TestMethod]
        public async Task UpdateResponseWithWorkflowReturnsCorrectTypeOnFormNotFound()
        {
            // Arrange
            _mockWorkflowService.Setup(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()))
               .Returns(Task.FromResult(new WorkflowStep() { Number = 2, Name = "GetFINumber", IsQueueable = true }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Never);
            //_mockQueueService.Verify(x => x.CreateQueueItem(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task UpdateResponseWithWorkflowReturnsCorrectTypeOnWorkflowNotFound()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            // _mockQueueService.Verify(x => x.CreateQueueItem(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task UpdateUserReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" }
            }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.User, new UserDetails() { Id = "userId", BusinessId = "businessId" });
            IHttpActionResult actionResult = await controller.UpdateUserAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Form>));
            var contentResult = actionResult as NegotiatedContentResult<Form>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
        }

        [TestMethod]
        public async Task UpdateUserReturnsCorrectTypeOnFormNotFound()
        {
            // Arrange
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.User, new UserDetails() { Id = "userId", BusinessId = "businessId" });
            IHttpActionResult actionResult = await controller.UpdateUserAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task UpdateWorkflowReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "Details" }
            }));
            _mockWorkflowService.Setup(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()))
               .Returns(Task.FromResult(new WorkflowStep() { Name = "NextStep", Number = 2 }));
            _mockWorkflowService.Setup(x => x.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(new Workflow()
                {
                    WorkflowId = "GeneralEnquiry",
                    Steps = new List<WorkflowStep>()
                    {
                        new WorkflowStep() { Number = 1, Name = "Details", IsQueueable = false },
                        new WorkflowStep() { Number = 2, Name = "GetFINumber", IsQueueable = true }
                    }
                }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Workflow, new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepId = "GetFINumber" });
            IHttpActionResult actionResult = await controller.UpdateWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            //_mockQueueService.Verify(x => x.CreateQueueItem(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Form>));
            var contentResult = actionResult as NegotiatedContentResult<Form>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
        }

        [TestMethod]
        public async Task UpdateWorkflowReturnsCorrectTypeOnFormNotFound()
        {
            // Arrange
            _mockWorkflowService.Setup(x => x.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(new Workflow()
                {
                    WorkflowId = "GeneralEnquiry",
                    Steps = new List<WorkflowStep>()
                    {
                        new WorkflowStep() { Number = 1, Name = "Details", IsQueueable = false },
                        new WorkflowStep() { Number = 2, Name = "GetFINumber", IsQueueable = true }
                    }
                }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Never);
            // _mockQueueService.Verify(x => x.CreateQueueItem(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task UpdateWorkflowReturnsCorrectTypeOnWorkflowNotFound()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = "formId",
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            // _mockQueueService.Verify(x => x.CreateQueueItem(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }


        [TestMethod]
        public async Task GetNextStepReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            _mockWorkflowService.Setup(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(new WorkflowStep() { Name = "TheNextStep", Number = 2, IsQueueable = false }));
            _mockWorkflowService.Setup(x => x.UpdateAsync(It.IsAny<Workflow>()))
                .Returns(Task.FromResult(new ResourceResponse<Document>() { }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Form>));
            var contentResult = actionResult as NegotiatedContentResult<Form>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
            Assert.AreEqual(contentResult.Content.Workflow.CurrentStepNumber, 2);
        }

        [TestMethod]
        public async Task GetNextStepReturnsCorrectTypeAndStatusOnWorkflowNotFound()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetNextStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task GetPreviousStepReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "TheNextStep", CurrentStepNumber = 2 }
            }));
            _mockWorkflowService.Setup(x => x.GetPreviousStepAsync(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(new WorkflowStep() { Name = "GeneralEnquiry", Number = 1, IsQueueable = false }));
            _mockWorkflowService.Setup(x => x.UpdateAsync(It.IsAny<Workflow>()))
               .Returns(Task.FromResult(new ResourceResponse<Document>() { }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc, WorkflowDirection.Previous);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetPreviousStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Form>));
            var contentResult = actionResult as NegotiatedContentResult<Form>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
            Assert.AreEqual(contentResult.Content.Workflow.CurrentStepNumber, 1);
        }

        [TestMethod]
        public async Task GetPreviousStepReturnsCorrectTypeAndStatusOnWorkflowNotFound()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "TheNextStep", CurrentStepNumber = 2 }
            }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc, WorkflowDirection.Previous);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetPreviousStepAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task GetCurrentStepReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            _mockWorkflowService.Setup(x => x.GetCurrentStepNumberAsync(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(new WorkflowStep() { Name = "GeneralEnquiry", Number = 1 }));
            _mockWorkflowService.Setup(x => x.UpdateAsync(It.IsAny<Workflow>()))
               .Returns(Task.FromResult(new ResourceResponse<Document>() { }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc, WorkflowDirection.Current);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetCurrentStepNumberAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Form>));
            var contentResult = actionResult as NegotiatedContentResult<Form>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
            Assert.AreEqual(contentResult.Content.Workflow.CurrentStepNumber, 1);
        }

        [TestMethod]
        public async Task GetCurrentStepReturnsCorrectTypeAndStatusOnWorkflowNotFound()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Response, new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() });
            IHttpActionResult actionResult = await controller.UpdateResponseWithWorkflowAsync("formId", patchDoc, WorkflowDirection.Current);

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetCurrentStepNumberAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockFormService.Verify(x => x.UpdateAsync(It.IsAny<Form>()), Times.Never);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task GetAllWorkFlowForFormReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));

            List<WorkflowStep> steps = new List<WorkflowStep>();
            for (int i = 1; i <= 8; i++)
                steps.Add(new WorkflowStep() { Name = string.Format("workFlow{0}", i), Number = (i), IsQueueable = false, Parameters = null });
            _mockWorkflowService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Workflow()
            {
                Steps = steps,
                WorkflowId = "workflowId",
                WorkflowType = "workflowtype",
            }));

            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            IHttpActionResult actionResult = await controller.GetFormWorkflowStepsAsync("formId");

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NegotiatedContentResult<Workflow>));
            var contentResult = actionResult as NegotiatedContentResult<Workflow>;
            Assert.AreEqual(HttpStatusCode.Accepted, contentResult.StatusCode);
            Assert.IsTrue(contentResult.Content.Steps.Count > 0);
            Assert.AreEqual(contentResult.Content.Steps.Count, 8);
        }

        [TestMethod]
        public async Task GetAllWorkFlowForFormReturnsCorrectTypeAndStatusOnNotFound()
        {
            // Arrange
            _mockFormService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Form()
            {
                SubmittedFormId = System.Guid.NewGuid().ToString(),
                FormTemplateId = "GeneralEnquiry",
                Workflow = new WorkflowDetails() { WorkflowId = "GeneralEnquiry", CurrentStepNumber = 1 }
            }));
            _mockWorkflowService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Workflow()
            {
                WorkflowId = "workflowId",
                WorkflowType = "workflowtype",
            }));

            var controller = new FormsController(_mockFormService.Object, _mockWorkflowService.Object, _mockTemplateService.Object, _mockQueueService.Object);

            // Act
            IHttpActionResult actionResult = await controller.GetFormWorkflowStepsAsync("formId");

            // Assert
            _mockFormService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }
    }
}
