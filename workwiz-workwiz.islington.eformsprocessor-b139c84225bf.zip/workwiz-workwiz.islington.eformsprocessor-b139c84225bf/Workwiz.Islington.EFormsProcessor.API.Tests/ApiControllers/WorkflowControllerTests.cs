﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Workwiz.Islington.EFormsProcessor.API.Controllers;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;

namespace Workwiz.Islington.EFormsProcessor.Tests.ApiControllers
{
    [TestClass]
    public class WorkflowControllerTests
    {
        private Mock<IWorkflowService> _mockWorkflowService;

        [TestInitialize]
        public void Initialize()
        {
            _mockWorkflowService = new Mock<IWorkflowService>();
        }

        [TestMethod]
        public async Task GetWorkflowByIdReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockWorkflowService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Workflow()
            {
                WorkflowId = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            }));
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.GetWorkflowByIdAsync("workflowId");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(OkNegotiatedContentResult<Workflow>));
            var contentResult = actionResult as OkNegotiatedContentResult<Workflow>;
            Assert.IsInstanceOfType(contentResult?.Content, typeof(Workflow));
        }

        [TestMethod]
        public async Task GetWorkflowByIdReturnsCorrectTypeAndStatusOnNotFound()
        {
            // Arrange
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.GetWorkflowByIdAsync("workflowId");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task CreateWorkflowReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockWorkflowService.Setup(x => x.CreateAsync(It.IsAny<Workflow>())).Returns(Task.FromResult(new Workflow()
            {
                WorkflowId = "abcdefg",
                WorkflowType = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            }));
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var workflow = new Workflow()
            {
                WorkflowType = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            };
            var actionResult = await controller.CreateAsync(workflow);

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(CreatedAtRouteNegotiatedContentResult<Workflow>));
            var contentResult = actionResult as CreatedAtRouteNegotiatedContentResult<Workflow>;
            Assert.IsFalse(string.IsNullOrEmpty(contentResult?.RouteName));
            Assert.IsFalse(string.IsNullOrEmpty(contentResult?.Content.WorkflowId));
            Assert.IsInstanceOfType(contentResult?.Content, typeof(Workflow));
        }

        [TestMethod]
        public async Task CreateWorkflowReturnsCorrectTypeAndStatusOnFailure()
        {
            // Arrange
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var workflow = new Workflow()
            {
                WorkflowType = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            };
            var actionResult = await controller.CreateAsync(workflow);

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(InternalServerErrorResult));
        }

        [TestMethod]
        public async Task GetAllWorkflowsReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockWorkflowService.Setup(x => x.GetAllAsync()).Returns(Task.FromResult(new List<Workflow>() {
                new Workflow()
            {
                WorkflowId = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            },
                new Workflow()
                {
                    WorkflowId = "2",
                    WorkflowType = "GeneralEnquiry",
                    Steps = new List<WorkflowStep>()
                    {
                        new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                        new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                    }
                }
            }));
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.GetAllWorkflowsAsync();

            // Assert
            var contentResult = actionResult as OkNegotiatedContentResult<List<Workflow>>;
            Assert.IsInstanceOfType(contentResult?.Content, typeof(List<Workflow>));
        }

        [TestMethod]
        public async Task GetAllWorkflowsReturnsCorrectTypeAndStatusOnNotFound()
        {
            // Arrange
            _mockWorkflowService.Setup(x => x.GetAllAsync()).Returns(Task.FromResult(new List<Workflow>()));
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.GetAllWorkflowsAsync();

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task GetAllWorkflowsReturnsCorrectTypeAndStatusOnFailure()
        {
            // Arrange
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.GetAllWorkflowsAsync();

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(InternalServerErrorResult));
        }

        [TestMethod]
        public async Task UpdateReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            var editedWorkflow = new Workflow()
            {
                WorkflowId = "ABCD",
                WorkflowType = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            };
            _mockWorkflowService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(editedWorkflow));
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.UpdateAsync("ABCD", editedWorkflow);

            // Assert
            _mockWorkflowService.Verify(x => x.UpdateAsync(It.IsAny<Workflow>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(OkNegotiatedContentResult<Workflow>));
        }

        [TestMethod]
        public async Task UpdateReturnsCorrectTypeAndStatusOnNotFound()
        {
            // Arrange
            var editedWorkflow = new Workflow()
            {
                WorkflowId = "ABCD",
                WorkflowType = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            };
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.UpdateAsync("ABCD", editedWorkflow);

            // Assert
            _mockWorkflowService.Verify(x => x.UpdateAsync(It.IsAny<Workflow>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task DeleteReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.DeleteAsync("ABCD");

            // Assert
            _mockWorkflowService.Verify(x => x.DeleteAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            var contentResult = actionResult as StatusCodeResult;
            Assert.AreEqual(HttpStatusCode.NoContent, contentResult?.StatusCode);
        }

        [TestMethod]
        public async Task DeleteReturnsCorrectTypeAndStatusOnFailure()
        {
            // Arrange
            _mockWorkflowService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(new Workflow()
            {
                WorkflowId = "ABCD",
                WorkflowType = "GeneralEnquiry",
                Steps = new List<WorkflowStep>()
                {
                    new WorkflowStep() {Number = 1, Name = "Details", IsQueueable = false},
                    new WorkflowStep() {Number = 2, Name = "GetFINumber", IsQueueable = true}
                }
            }));
            var controller = new WorkflowController(_mockWorkflowService.Object);

            // Act
            var actionResult = await controller.DeleteAsync("ABCD");

            // Assert
            _mockWorkflowService.Verify(x => x.DeleteAsync(It.IsAny<string>()), Times.Once);
            _mockWorkflowService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            var contentResult = actionResult as StatusCodeResult;
            Assert.IsInstanceOfType(actionResult, typeof(InternalServerErrorResult));
        }
    }
}
