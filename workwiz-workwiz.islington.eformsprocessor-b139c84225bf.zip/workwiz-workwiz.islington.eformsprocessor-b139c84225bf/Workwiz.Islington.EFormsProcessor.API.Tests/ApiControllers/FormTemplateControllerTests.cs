﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Workwiz.Islington.EFormsProcessor.API.Controllers;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;

namespace Workwiz.Islington.EFormsProcessor.Tests.ApiControllers
{
    [TestClass]
    public class FormTemplateControllerTests
    {
        private Mock<IFormTemplateService> _mockTemplateService;

        [TestInitialize]
        public void Initialise()
        {
            _mockTemplateService = new Mock<IFormTemplateService>();
        }

        [TestMethod]
        public async Task GetTemplateByNameReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockTemplateService.Setup(x => x.GetByNameAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(new FormTemplate()));
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.GetByNameAsync("workflowId");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(OkNegotiatedContentResult<FormTemplate>));
            var contentResult = actionResult as OkNegotiatedContentResult<FormTemplate>;
            Assert.IsInstanceOfType(contentResult?.Content, typeof(FormTemplate));
        }

        [TestMethod]
        public async Task GetTemplateByNameReturnsCorrectStatusOnNotFound()
        {
            // Arrange
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.GetByNameAsync("workflowId");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task GetTemplateByFormNameReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            List<FormTemplate> result = new List<FormTemplate>() { new FormTemplate() };
            _mockTemplateService.Setup(x => x.GetByFormNameAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(result));

            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.GetByFormNameAsync("workflowId");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(OkNegotiatedContentResult<FormTemplate>));
            var contentResult = actionResult as OkNegotiatedContentResult<FormTemplate>;
            Assert.IsInstanceOfType(contentResult?.Content, typeof(FormTemplate));
        }

        [TestMethod]
        public async Task GetTemplateByFormNameReturnsCorrectStatusOnNotFound()
        {
            // Arrange
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.GetByFormNameAsync("workflowId");

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task GetAllReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            _mockTemplateService.Setup(x => x.GetAllAsync()).Returns(Task.FromResult(new List<FormTemplate>()));
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.GetAllAsync();

            // Assert
            // Assert
            var contentResult = actionResult as OkNegotiatedContentResult<List<FormTemplate>>;
            Assert.IsInstanceOfType(contentResult?.Content, typeof(List<FormTemplate>));
        }

        [TestMethod]
        public async Task CreateReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            var savedTemplate = new FormTemplate()
            {
                FormType = "GeneralEnquiry",
                WorkflowType = "GeneralEnquiry"
            };
            _mockTemplateService.Setup(x => x.CreateAsync(It.IsAny<FormTemplate>()))
                .Returns(Task.FromResult(savedTemplate));
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.CreateAsync(savedTemplate);

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(CreatedAtRouteNegotiatedContentResult<FormTemplate>));
            var contentResult = actionResult as CreatedAtRouteNegotiatedContentResult<FormTemplate>;
            Assert.IsFalse(string.IsNullOrEmpty(contentResult?.RouteName));
            Assert.IsFalse(string.IsNullOrEmpty(contentResult?.Content.FormType));
            Assert.IsInstanceOfType(contentResult?.Content, typeof(FormTemplate));
        }

        [TestMethod]
        public async Task CreateReturnsCorrectTypeAndStatusOnFailure()
        {
            // Arrange
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var savedTemplate = new FormTemplate()
            {
                FormType = "GeneralEnquiry",
                WorkflowType = "GeneralEnquiry"
            };
            var actionResult = await controller.CreateAsync(savedTemplate);

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(InternalServerErrorResult));
        }

        [TestMethod]
        public async Task UpdateReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            var savedTemplate = new FormTemplate()
            {
                FormType = "GeneralEnquiry",
                WorkflowType = "GeneralEnquiry"
            };
            _mockTemplateService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(savedTemplate));
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.UpdateAsync("ABCD", savedTemplate);

            // Assert
            _mockTemplateService.Verify(x => x.UpdateAsync(It.IsAny<FormTemplate>()), Times.Once);
            _mockTemplateService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(OkNegotiatedContentResult<FormTemplate>));
        }

        [TestMethod]
        public async Task UpdateReturnsCorrectTypeAndStatusOnNotFound()
        {
            // Arrange
            var savedTemplate = new FormTemplate()
            {
                FormType = "GeneralEnquiry",
                WorkflowType = "GeneralEnquiry"
            };
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.UpdateAsync("ABCD", savedTemplate);

            // Assert
            _mockTemplateService.Verify(x => x.UpdateAsync(It.IsAny<FormTemplate>()), Times.Once);
            _mockTemplateService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public async Task DeleteReturnsCorrectTypeAndStatusOnSuccess()
        {
            // Arrange
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.DeleteAsync("ABCD");

            // Assert
            _mockTemplateService.Verify(x => x.DeleteAsync(It.IsAny<string>()), Times.Once);
            _mockTemplateService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            var contentResult = actionResult as StatusCodeResult;
            Assert.AreEqual(HttpStatusCode.NoContent, contentResult?.StatusCode);
        }

        [TestMethod]
        public async Task DeleteReturnsCorrectTypeAndStatusOnFailure()
        {
            // Arrange
            _mockTemplateService.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(
            new FormTemplate()
            {
                FormType = "GeneralEnquiry",
                WorkflowType = "GeneralEnquiry"
            }));
            var controller = new FormTemplateController(_mockTemplateService.Object);

            // Act
            var actionResult = await controller.DeleteAsync("ABCD");

            // Assert
            _mockTemplateService.Verify(x => x.DeleteAsync(It.IsAny<string>()), Times.Once);
            _mockTemplateService.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actionResult);
            Assert.IsInstanceOfType(actionResult, typeof(InternalServerErrorResult));
        }
    }
}

