﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Workwiz.Islington.EFormsProcessor.ApiClient;

namespace Workwiz.Islington.EFormsProcessor.BackgroundAgentService
{
    /// <summary>
    /// </summary>
    public class QueueManager
    {
        private readonly NamespaceManager _namespaceManager;
        private readonly MessagingFactory _factory;
        private TopicClient _topicClient;
        public QueueManager(string connectionString)
        {
            _namespaceManager = NamespaceManager.CreateFromConnectionString(connectionString);
            _factory = MessagingFactory.CreateFromConnectionString(connectionString);
            Console.WriteLine("Service bus address {0}", _namespaceManager.Address);
        }

        
        public void ListTopicsAndSubscriptions()
        {
            IEnumerable<TopicDescription> topicDescriptions = _namespaceManager.GetTopics();
            Console.WriteLine("Lisiting topics and subscriptions...");
            foreach (TopicDescription topicDescription in topicDescriptions)
            {
                Console.WriteLine("\t{0}", topicDescription.Path);
                IEnumerable<SubscriptionDescription> subscriptionDescriptions = _namespaceManager.GetSubscriptions(topicDescription.Path);
                foreach (SubscriptionDescription subscriptionDescription in subscriptionDescriptions)
                {
                    Console.WriteLine("\t\t{0}", subscriptionDescription.Name);
                }
            }
            Console.WriteLine("Done!");
        }

        //public void ReceiveFromSubscriptions(string topicPath)
        //{

        //    Console.WriteLine("Receiving from topic {0} subscriptions.", topicPath);

        //    foreach (SubscriptionDescription subDescription in
        //        _namespaceManager.GetSubscriptions(topicPath))
        //    {

        //        Console.WriteLine("Receiving from subscription {0}...", subDescription.Name);

        //        SubscriptionClient subClient =
        //            _factory.CreateSubscriptionClient(topicPath, subDescription.Name);
        //        var options = new OnMessageOptions();
        //        options.AutoComplete = false;
        //        options.AutoRenewTimeout = TimeSpan.FromMinutes(1);

        //        while (true)
        //        {

        //            BrokeredMessage message = subClient.Receive(TimeSpan.FromSeconds(5));
        //            if (message != null)
        //            {
        //                try
        //                {
        //                    Console.WriteLine(" Message Id-{0} FormId-{1}",
        //                    message.MessageId, message.Properties["FormId"]);
        //                    var agent =
        //                        (IFormAgent)
        //                            GetInstance(string.Format("Workwiz.Islington.EFormsProcessor.Agents.{0}",
        //                                subDescription.Name));
        //                    agent.Process(message);

        //                    message.Complete();
        //                }
        //                catch(MessagingException exception)
        //                {
        //                    //log error
        //                    message.Abandon();
        //                }
        //            }
        //            else
        //            {
        //                Console.WriteLine();
        //                break;
        //            }
        //        }
        //        subClient.Close();
        //    }
        //}

        public async void SendPdfTestMessage()
        {
            var formsClient = new FormsClient();
            var form = new Form()
            {
                FormTemplateId = "MessageTestForm",
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>()}
            };
            form.Response.Answers.Add("WhatsThisThen", new UserResponseItem() { Question = "Is this a messaging test?", Answer = "It most certainly is" });

            try
            {


                var savedForm = await formsClient.Create(form);

                if (savedForm != null)
                {
                    Console.WriteLine("Form created, id: " + savedForm.SubmittedFormId);
                    await formsClient.UpdateResponseProgressWorkflow(savedForm.SubmittedFormId, savedForm.Response);
                }
                else
                {
                    Console.WriteLine("Failed to create form");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                if (ex.InnerException != null)
                {
                    Console.WriteLine(ex.InnerException.Message);
                }
            }
            //_topicClient = _factory.CreateTopicClient(topic);
            //var message = new BrokeredMessage();
            //var step = Guid.NewGuid().ToString();
            //message.Label = string.Format("Message {0} created  {1}", step, DateTime.UtcNow);
            ////this form application exist
            //message.MessageId = "7e18493a-546d-47a9-94d2-f1a291a94ab1"; //Guid.NewGuid().ToString();
            //message.Properties.Add("Type", "pdf");
            //message.Properties.Add("Step", step);
            //_topicClient.Send(message);
            //_topicClient.Close();
            //Console.WriteLine("Sent message into queue..........");
        }
                
        public object GetInstance(string strFullyQualifiedName)
        {
            Type type = Type.GetType(strFullyQualifiedName);
            if (type != null)
                return Activator.CreateInstance(type);
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                type = asm.GetType(strFullyQualifiedName);
                if (type != null)
                    return Activator.CreateInstance(type);
            }
            return null;
        }
    }
}
