﻿using Ninject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Ninject.Extensions.Conventions;
using NLog;

namespace Workwiz.Islington.EFormsProcessor.BackgroundAgentService
{
    public partial class Service1 : ServiceBase
    {
        protected NLog.Logger Logger { get; private set; }
        IEnumerable<IFormAgent> _agents;
        public Service1()
        {
            InitializeComponent();
            try
            {

                Logger = LogManager.GetLogger(GetType().FullName);
                Logger.Info("Initialising Service ..");
                var kernel = CreateKernel();
                var agentsLoaded = kernel.GetAll(typeof(IFormAgent));
                var agentstoBeInstalled = agentsLoaded
                    .Where(a => Shared.Properties.Settings.Default.BlockedAgents.Contains(((IFormAgent)a).AgentName.ToLower()) == false)
                    .ToList().Cast<IFormAgent>();
                this._agents = agentstoBeInstalled;
                Logger.Info("Service initialised successfully");
            }
            catch (Exception e)
            {
                Logger.Fatal(e, "Error while initializing service");
            }

        }

        protected override void OnStart(string[] args)
        {
            Logger.Info("Starting Service ..");
            if (_agents?.Count() > 0)
            {
                foreach (var item in _agents)
                {
                    try
                    {
                        item.Start();
                    }
                    catch (Exception e)
                    {
                        Logger.Error(e,"Error while starting {0}",item.AgentName);
                    }
                    
                }
            }
            Logger.Info("Service started successfully..");
        }

        protected override void OnStop()
        {
            Logger.Info("Stopping Service ..");
            if (_agents?.Count() > 0)
            {
                foreach (var item in _agents)
                {
                    item.Stop();
                }
            }
            Logger.Info("Service stopped successfully..");
        }

        static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());
            RegisterServices(kernel);
            return kernel;
        }
        static void RegisterServices(IKernel kernel)
        {
            kernel.Bind(x => x.FromAssembliesMatching("Workwiz.Islington.EFormsProcessor.Agents.*")
           .SelectAllClasses()
           .InheritedFrom(typeof(IFormAgent))
           .BindAllInterfaces());

            kernel.Bind<DocumentStore.Client.IDocumentStoreHttpClient>()
                .To<DocumentStore.Client.DocumentStoreHttpClient>();
        }
    }
}
