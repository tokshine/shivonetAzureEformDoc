﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Marvin.JsonPatch;
using Marvin.JsonPatch.Dynamic;
using Workwiz.Islington.EFormsProcessor.API.Filters;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Workwiz.Islington.EFormsProcessor.Shared.Enums;

namespace Workwiz.Islington.EFormsProcessor.API.Controllers
{
    /// <summary>
    /// Web API Controller class for Forms operations
    /// </summary>
    [EFormsProcessorException]
    [RoutePrefix("forms")]
    public class FormsController : ApiController
    {
        private readonly IFormService _formService;
        private readonly IWorkflowService _workFlowService;
        private readonly IFormTemplateService _templateService;
        private readonly IQueueService _queueService;

        /// <summary>
        /// Initializes a new instance of the <see cref="FormsController"/> class.
        /// </summary>
        /// <param name="formService">The form service.</param>
        /// <param name="workFlowService">The work flow service.</param>
        /// <param name="templateService">The template service.</param>
        /// <param name="queueService">The queue service.</param>
        public FormsController(IFormService formService, IWorkflowService workFlowService, IFormTemplateService templateService, IQueueService queueService)
        {
            _formService = formService;
            _workFlowService = workFlowService;
            _templateService = templateService;
            _queueService = queueService;
        }


        // GET /forms/{formId}
        /// <summary>
        /// GetFormById
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        [Route("{formId}")]
        [ResponseType(typeof(Task<Form>))]
        public async Task<IHttpActionResult> GetFormByIdAsync(string formId)
        {
            var form = await _formService.GetAsync(formId);
            if (form == null)
            {
                return NotFound();
            }

            return Ok(form);
        }

        // GET /forms/search
        [HttpGet]
        [Route("search")]
        public async Task<List<Form>> SearchAsync(string searchParameters)
        {
            throw new NotImplementedException();
        }

        // POST /forms
        /// <summary>
        /// Create
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        [ResponseType(typeof(Task<Form>))]
        public async Task<IHttpActionResult> CreateAsync(Form form)
        {
            if (string.IsNullOrEmpty(form.FormTemplateId))
            {
                return NotFound();
            }

            var formTemplates = await _templateService.GetByFormNameAsync(form.FormTemplateId);
            if (!formTemplates.Any())
            {
                return NotFound();
            }
            var workflow = await _workFlowService.GetByTypeAsync(formTemplates.First().WorkflowType);
            if (workflow == null
                || workflow.Steps.FirstOrDefault() == null
                || workflow.Steps.FirstOrDefault(s => s.Number == 1) == null)
            {
                return NotFound();
            }
            WorkflowStep firststep = workflow.Steps.FirstOrDefault();
            form.Workflow = new WorkflowDetails()
            {
                WorkflowId = workflow.WorkflowId,
                CurrentStepId = firststep.Name,
                CurrentStepNumber = firststep.Number,
                FurthestStepNumber = firststep.Number,
            };

            var savedForm = await _formService.CreateAsync(form);
            if (savedForm == null)
            {
                return InternalServerError();
            }


            //#region proof of concept |remove code when queue service is in place       
            //Workwiz.Islington.EFormsProcessor.Agents.PdfAgent.GeneratePdf(savedForm.SubmittedFormId);            
            //#endregion

            return CreatedAtRoute("DefaultApi", new { controller = "forms", id = savedForm.SubmittedFormId }, savedForm);
        }

        // PATCH /forms/{formId}/response        
        /// <summary>
        /// Updates the response asynchronous - This will update (Patch) the response in the Json, it does NOT update the workflow steps.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="formPatchDocument">The form patch document.</param>
        /// <returns></returns>
        [HttpPatch]
        [Route("{formId}/response")]
        [ResponseType(typeof(Task<Form>))]
        public async Task<IHttpActionResult> UpdateResponseAsync(string formId, [FromBody]JsonPatchDocument<Form> formPatchDocument)
        {
            var form = await _formService.GetAsync(formId);
            if (form == null)
            {
                return NotFound();
            }
            formPatchDocument.ApplyTo(form);
            await _formService.UpdateAsync(form);
            return Content(HttpStatusCode.Accepted, form);
        }


        // PATCH /forms/{formId}/workflowDirection/{direction}/dynamic       
        /// <summary>
        /// Updates the form with step completed asynchronous
        /// This method has gone through a number of iterations since being created by shina on 03-08-2016.
        /// It has been updated by geriant a number of times and ended up doing the same as UpdateResponseWithWorkflowAsync.
        /// The only difference is the method parameters i.e. "[FromBody]JsonPatchDocument" instead of "[FromBody]JsonPatchDocument<Form>"
        /// As nothing in the sitecore site uses this method I have marked it as obsolete however it can be reinstaed if needed.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="formPatchDocument">The form patch document.</param>
        /// <param name="direction">The next step.</param>
        /// <returns></returns>
        [Obsolete("Use UpdateResponseWithWorkflowAsync instead")]
        [HttpPatch]
        [Route("{formId}/workflowDirection/{direction}/dynamic")]
        [ResponseType(typeof(Task<Form>))]
        public async Task<IHttpActionResult> UpdateFormWithStepCompletedAsync(string formId, [FromBody]JsonPatchDocument formPatchDocument, WorkflowDirection direction = WorkflowDirection.Next)
        {
            var form = await _formService.GetAsync(formId);
            if (form == null)
            {
                return NotFound();
            }

            //if (form.SectionsCompleted == null)
            //{
            //    form.SectionsCompleted = new List<dynamic>();
            //    var patchDoc = new JsonPatchDocument<Form>();
            //    patchDoc.Replace(c => c.SectionsCompleted, form.SectionsCompleted);
            //    patchDoc.Add(c => c.SectionsCompleted, formPatchDocument);
            //    patchDoc.ApplyTo(form);
            //}

            formPatchDocument.ApplyTo(form);

            var step = await GetWorkFlowStep(form, direction);
            if (step != null)
            {
                int furthestStep = (step.Number < form.Workflow.FurthestStepNumber) ? form.Workflow.FurthestStepNumber : step.Number;
                var wfPatchDoc = new JsonPatchDocument<Form>();
                wfPatchDoc.Replace(r => r.Workflow,
                    new WorkflowDetails()
                    {
                        CurrentStepId = step.Name,
                        WorkflowId = form.Workflow.WorkflowId,
                        CurrentStepNumber = step.Number,
                        FurthestStepNumber = furthestStep,
                    });
                wfPatchDoc.ApplyTo(form);

                if (step.IsQueueable)
                {
                    _queueService.CreateQueueItem(step, formId);
                }
            }

            await _formService.UpdateAsync(form);
            return Content(HttpStatusCode.Accepted, form);
        }

        // PATCH /forms/{formId}/workflowDirection/{direction}/response               
        /// <summary>
        /// Updates the response with workflow asynchronous.
        /// This wil update (Patch) the response AND update the workflow to the "next", "previous" or "current" step.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="formPatchDocument">The form patch document.</param>
        /// <param name="direction">The next step.</param>
        /// <returns></returns>
        [HttpPatch]
        [Route("{formId}/workflowDirection/{direction}/response")]
        [ResponseType(typeof(Task<Form>))]
        public async Task<IHttpActionResult> UpdateResponseWithWorkflowAsync(string formId, [FromBody]JsonPatchDocument<Form> formPatchDocument, WorkflowDirection direction = WorkflowDirection.Next)
        {
            var form = await _formService.GetAsync(formId);
            if (form == null)
            {
                return NotFound();
            }

            var step = await GetWorkFlowStep(form, direction);
            if (step == null)
            {
                return NotFound();
            }

            int furthestStep = (step.Number < form.Workflow.FurthestStepNumber) ? form.Workflow.FurthestStepNumber : step.Number;
            var patchDoc = new JsonPatchDocument<Form>();
            patchDoc.Replace(r => r.Workflow,
                new WorkflowDetails()
                {
                    CurrentStepId = step.Name,
                    WorkflowId = form.Workflow.WorkflowId,
                    CurrentStepNumber = step.Number,
                    FurthestStepNumber = furthestStep
                });

            if (step.IsQueueable)
            {
                _queueService.CreateQueueItem(step, formId);
            }

            formPatchDocument.ApplyTo(form);
            patchDoc.ApplyTo(form);

            await _formService.UpdateAsync(form);
            return Content(HttpStatusCode.Accepted, form);
        }

        // PATCH /forms/{formId}/user      
        /// <summary>
        /// Updates the user asynchronous.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="formPatchDocument">The form patch document.</param>
        /// <returns></returns>
        [HttpPatch]
        [Route("{formId}/user")]
        [ResponseType(typeof(Task<Form>))]
        public async Task<IHttpActionResult> UpdateUserAsync(string formId, [FromBody]JsonPatchDocument<Form> formPatchDocument)
        {
            var form = await _formService.GetAsync(formId);
            if (form == null)
            {
                return NotFound();
            }
            formPatchDocument.ApplyTo(form);
            await _formService.UpdateAsync(form);
            return Content(HttpStatusCode.Accepted, form);
        }

        // PATCH /forms/{formId}/workflowDirection/{direction}/workflow               
        /// <summary>
        /// Updates the response with workflow asynchronous.
        /// This wil update (Patch) the response AND update the workflow to the "next", "previous" or "current" step.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="formPatchDocument">The form patch document.</param>
        /// <param name="direction">The next step.</param>
        /// <returns></returns>
        [HttpPatch]
        [Route("{formId}/workflowDirection/{direction}/workflow")]
        [ResponseType(typeof(Task<Form>))]
        public async Task<IHttpActionResult> UpdateWorkflowAsync(string formId, [FromBody]JsonPatchDocument<Form> formPatchDocument, WorkflowDirection direction = WorkflowDirection.Next)
        {
            var form = await _formService.GetAsync(formId);
            if (form == null)
            {
                return NotFound();
            }
            formPatchDocument.ApplyTo(form);

            var workFlow = await _workFlowService.GetAsync(form.Workflow.WorkflowId);
            if (workFlow == null)
            {
                return NotFound();
            }
            var step = await GetWorkFlowStep(form, direction);
            if (step == null)
            {
                return NotFound();
            }

            if (step.IsQueueable)
            {
                _queueService.CreateQueueItem(step, formId);
            }

            await _formService.UpdateAsync(form);
            return Content(HttpStatusCode.Accepted, form);
        }

        // GET /forms/{formId}/getFormWorkflowSteps               
        /// <summary>
        /// Gets all workflow asynchronous.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <returns></returns>
        [Route("{formId}/getFormWorkflowSteps")]
        [ResponseType(typeof(Task<Workflow>))]
        public async Task<IHttpActionResult> GetFormWorkflowStepsAsync(string formId)
        {
            var form = await _formService.GetAsync(formId);
            if (form == null)
            {
                return NotFound();
            }
            Workflow workFlow = await _workFlowService.GetAsync(form.Workflow.WorkflowId);
            if (workFlow == null || workFlow.Steps == null)
            {
                return NotFound();
            }
            return Content(HttpStatusCode.Accepted, workFlow);
        }

        /// <summary>
        /// Gets the work flow step.
        /// </summary>
        /// <param name="form">The form.</param>
        /// <param name="direction">The direction.</param>
        /// <returns></returns>
        private async Task<WorkflowStep> GetWorkFlowStep(Form form, WorkflowDirection direction = WorkflowDirection.Next)
        {
            if (direction == WorkflowDirection.Next)
                return await _workFlowService.GetNextStepAsync(form.Workflow.WorkflowId, form.Workflow.CurrentStepNumber);
            else if (direction == WorkflowDirection.Previous)
                return await _workFlowService.GetPreviousStepAsync(form.Workflow.WorkflowId, form.Workflow.CurrentStepNumber);
            else
                return await _workFlowService.GetCurrentStepNumberAsync(form.Workflow.WorkflowId, form.Workflow.CurrentStepNumber);
        }
    }
}
