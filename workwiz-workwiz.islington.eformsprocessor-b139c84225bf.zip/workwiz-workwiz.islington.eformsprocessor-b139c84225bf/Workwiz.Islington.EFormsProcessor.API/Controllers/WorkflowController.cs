﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Workwiz.Islington.EFormsProcessor.API.Filters;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Swashbuckle.Swagger.Annotations;

namespace Workwiz.Islington.EFormsProcessor.API.Controllers
{
    /// <summary>
    /// Web API Controller class for Workflow operations
    /// </summary>
    [EFormsProcessorException]
    [RoutePrefix("workflows")]
    public class WorkflowController : ApiController
    {
        private readonly IWorkflowService _workflowService;

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowController"/> class.
        /// </summary>
        /// <param name="workflowService">The workflow service.</param>
        public WorkflowController(IWorkflowService workflowService)
        {
            _workflowService = workflowService;
        }
        
        // GET /workflows/{workflowId}
        /// <summary>
        /// GetWorkflowByIdAsync
        /// </summary>
        /// <param name="workflowId"></param>
        /// <returns></returns>
        [Route("{workflowId}")]
        [ResponseType(typeof(Task<Workflow>))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the Workflow on success", typeof(Workflow))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Returns 404 Not Found if no workflow found with the given workflowId")]
        public async Task<IHttpActionResult> GetWorkflowByIdAsync(string workflowId)
        {
            var workflow = await _workflowService.GetAsync(workflowId);
            if (workflow == null)
            {
                return NotFound();
            }
            return Ok(workflow);
        }

        // GET /workflows/
        /// <summary>
        /// GetAllWorkflowsAsync
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("")]
        [ResponseType(typeof(Task<List<Workflow>>))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the all the Workflows on success", typeof(List<Workflow>))]
        public async Task<IHttpActionResult> GetAllWorkflowsAsync()
        {
            Trace.Write("Started method");
            var workflows = await _workflowService.GetAllAsync();
            //Trace.Write("Back from service");
            //if (workflows == null)
            //{
            //    Trace.Write("Null response");
            //    return InternalServerError();
            //}
            //if (workflows.Count == 0)
            //{
            //    Trace.Write("No workflows");
            //    return NotFound();
            //}
            //Trace.Write("Returning");
            return Ok(workflows);
        }

        // GET /workflows/search        
        /// <summary>
        /// Search
        /// </summary>
        /// <param name="searchParameters">The search parameters.</param>
        /// <returns></returns>
        /// <exception cref="System.NotImplementedException"></exception>
        [HttpGet]
        [Route("search")]
        [ResponseType(typeof(Task<List<Workflow>>))]
        [SwaggerResponse(HttpStatusCode.NotImplemented)]
        public async Task<IHttpActionResult> SearchAsync(object searchParameters)
        {
            throw new NotImplementedException();
        }

        // POST /workflows
        /// <summary>
        /// CreateAsync
        /// </summary>
        /// <param name="workflow"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        [ResponseType(typeof(Task<Workflow>))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the new Workflow on success", typeof(Workflow))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Returns InternalServerError if workflow could not be created")]
        public async Task<IHttpActionResult> CreateAsync(Workflow workflow)
        {
            var savedWorkflow = await _workflowService.CreateAsync(workflow);
            if (savedWorkflow == null)
            {
                return InternalServerError();
            }
            return CreatedAtRoute("DefaultApi", new { controller = "workflow", id = savedWorkflow.WorkflowId }, savedWorkflow);
        }

        // PUT /workflows/{workflowId}
        /// <summary>
        /// UpdateAsync
        /// </summary>
        /// <param name="workflowId"></param>
        /// <param name="workflow"></param>
        ///  <returns></returns>
        [HttpPut]
        [Route("{workflowId}")]
        [ResponseType(typeof(Task<Workflow>))]
        [SwaggerResponse(HttpStatusCode.Accepted, "Returns the updated Workflow on success", typeof(Workflow))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Returns 404 Not Found if the given workflowId is not found")]
        public async Task<IHttpActionResult> UpdateAsync(string workflowId, Workflow workflow)
        {
            await _workflowService.UpdateAsync(workflow);
            var editedWorkflow = await _workflowService.GetAsync(workflowId);
            if (editedWorkflow == null)
            {
                return NotFound();
            }
            return Ok(editedWorkflow);
        }

        // DELETE /workflows/{workflowId}
        /// <summary>
        /// DeleteAsync
        /// </summary>
        /// <param name="workflowId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("{workflowId}")]
        [SwaggerResponse(HttpStatusCode.NoContent, "Returns No Content on success")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Returns InternalServerError if unable to delete Workflow")]
        public async Task<IHttpActionResult> DeleteAsync(string workflowId)
        {
            await _workflowService.DeleteAsync(workflowId);
            var deletedWorkflow = await _workflowService.GetAsync(workflowId);
            if (deletedWorkflow == null)
            {
                return StatusCode(HttpStatusCode.NoContent);
            }
            return InternalServerError();
        }
    }
}
