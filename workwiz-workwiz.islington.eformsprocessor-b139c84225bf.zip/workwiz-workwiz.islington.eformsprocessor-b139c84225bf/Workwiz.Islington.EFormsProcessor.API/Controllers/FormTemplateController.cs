﻿using Swashbuckle.Swagger.Annotations;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Workwiz.Islington.EFormsProcessor.API.Filters;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;

namespace Workwiz.Islington.EFormsProcessor.API.Controllers
{
    /// <summary>
    /// Web API controller for Form Templates, relating form types to workflows
    /// </summary>
    [EFormsProcessorException]
    [RoutePrefix("templates")]
    public class FormTemplateController : ApiController
    {
        private IFormTemplateService _templateService;

        public FormTemplateController(IFormTemplateService templateService)
        {
            _templateService = templateService;
        }

        // GET /templates/id/{id}
        /// <summary>
        /// GetAsync
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("{id}")]
        [ResponseType(typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the FormTemplate on success", typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Returns 404 Not Found if no FormTemplate found with the given formTemplateId")]
        public async Task<IHttpActionResult> GetAsync(string id)
        {
            var template = await _templateService.GetAsync(id);
            if (template == null)
            {
                return NotFound();
            }
            return Ok(template);
        }

        // GET /templates/name/{name}
        /// <summary>
        /// GetByNameAsync
        /// </summary>
        /// <param name="templateName"></param>
        /// <returns></returns>
        [Route("name/{templateName}")]
        [ResponseType(typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the FormTemplate on success", typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Returns 404 Not Found if no FormTemplate found with the given templateName")]
        public async Task<IHttpActionResult> GetByNameAsync(string templateName)
        {
            var template = await _templateService.GetByNameAsync(templateName);
            if (template == null)
            {
                return NotFound();
            }
            return Ok(template);
        }

        // GET /templates/form/{formName}
        /// <summary>
        /// GetByFormNameAsync
        /// </summary>
        /// <param name="formName"></param>
        /// <returns></returns>
        [Route("form/{formName}")]
        [ResponseType(typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the FormTemplate on success", typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Returns 404 Not Found if no FormTemplate found with the given formName")]
        public async Task<IHttpActionResult> GetByFormNameAsync(string formName)
        {
            var templates = await _templateService.GetByFormNameAsync(formName);
            if (templates == null || !templates.Any())
            {
                return NotFound();
            }
            return Ok(templates.First());
        }

        // GET /templates
        /// <summary>
        /// GetAllAsync
        /// </summary>
        /// <returns></returns>
        [Route("")]
        [ResponseType(typeof(List<FormTemplate>))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the all the FormTemplates on success", typeof(List<FormTemplate>))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Returns InternalServerError if the FormTemplate retrieval failed")]
        public async Task<IHttpActionResult> GetAllAsync()
        {
            var templates = await _templateService.GetAllAsync();
            if (templates == null)
            {
                return InternalServerError();
            }
            return Ok(templates);
        }

        // POST /templates
        /// <summary>
        /// CreateAsync
        /// </summary>
        /// <param name="formTemplate"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        [ResponseType(typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.OK, "Returns the new FormTemplate on success", typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Returns InternalServerError if FormTemplate could not be created")]
        public async Task<IHttpActionResult> CreateAsync(FormTemplate formTemplate)
        {
            var savedTemplate = await _templateService.CreateAsync(formTemplate);
            if (savedTemplate == null)
            {
                return InternalServerError();
            }
            return CreatedAtRoute("GetTemplate", new { id = savedTemplate.TemplateId }, savedTemplate);
        }

        // PUT /templates/{templateId}
        /// <summary>
        /// UpdateAsync
        /// </summary>
        /// <param name="templateId"></param>
        /// <param name="formTemplate"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("{templateId}")]
        [ResponseType(typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.Accepted, "Returns the updated FormTemplate on success", typeof(FormTemplate))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Returns 404 Not Found if the given formTemplateId is not found")]
        public async Task<IHttpActionResult> UpdateAsync(string templateId, FormTemplate formTemplate)
        {
            await _templateService.UpdateAsync(formTemplate);
            var editedWorkflow = await _templateService.GetAsync(formTemplate.TemplateId);
            if (editedWorkflow == null)
            {
                return NotFound();
            }
            return Ok(editedWorkflow);
        }

        // DELETE /templates/{templateId}
        /// <summary>
        /// DeleteAsync
        /// </summary>
        /// <param name="templateId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("{templateId}")]
        [SwaggerResponse(HttpStatusCode.NoContent, "Returns No Content on success")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Returns InternalServerError if unable to delete FormTemplate")]
        public async Task<IHttpActionResult> DeleteAsync(string templateId)
        {
            await _templateService.DeleteAsync(templateId);
            var deletedTemplate = await _templateService.GetAsync(templateId);
            if (deletedTemplate == null)
            {
                return StatusCode(HttpStatusCode.NoContent);
            }
            return InternalServerError();
        }
    }
}
