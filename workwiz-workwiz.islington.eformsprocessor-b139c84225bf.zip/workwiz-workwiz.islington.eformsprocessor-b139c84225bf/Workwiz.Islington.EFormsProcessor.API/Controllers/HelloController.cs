﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;

namespace Workwiz.Islington.EFormsProcessor.API.Controllers
{
    [RoutePrefix("hello")]
    public class HelloController : ApiController
    {
        private readonly IWorkflowService _workflowService;

        public HelloController(IWorkflowService workflowService)
        {
            _workflowService = workflowService;
        }
        
        // GET /hello/{name}
        /// <summary>
        /// SayHello
        /// </summary>
        /// <param name="workflowId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("")]
        [ResponseType(typeof(Task<string>))]
        public async Task<string> SayHello(string name)
        {
            await _workflowService.GetAllAsync();
            return "Hello " + name;
        }

        private async Task DoStuff()
        {
            await Task.Run(() => { Thread.Sleep(20000); });
        }
    }
}
