﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using MB.Owin.Logging.Log4Net;
using Microsoft.Owin.Extensions;
using Microsoft.Owin.Logging;
using Ninject.Web.Common.OwinHost;
using Ninject.Web.WebApi.OwinHost;
using Owin;
using Swashbuckle.Application;
using Workwiz.Islington.EFormsProcessor.API.Filters;

namespace Workwiz.Islington.EFormsProcessor.API
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();
            WebApiConfig.Register(config);

            // references MB.Owin>logging.Log4Nert NuGet
            app.UseLog4Net("~/Web.config");
            
            // references custom exception attribute
            config.Services.Replace(typeof(IExceptionHandler), new EFormsProcessorExceptionHandler(app.CreateLogger<Startup>()));

            SwaggerConfig.Register(config);

            // references Ninject.* NuGet
            app.UseNinjectMiddleware(() => NinjectConfig.CreateKernel.Value);
            app.UseNinjectWebApi(config);
        }
    }
}