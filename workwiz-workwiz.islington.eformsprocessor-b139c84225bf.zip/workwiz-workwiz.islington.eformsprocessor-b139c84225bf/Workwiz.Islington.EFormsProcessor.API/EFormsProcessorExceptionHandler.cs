﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.ExceptionHandling;
using System.Web.Http.Results;
using Microsoft.Owin.Logging;
using Ninject;

namespace Workwiz.Islington.EFormsProcessor.API
{
    public class EFormsProcessorExceptionHandler : ExceptionHandler
    {
        private ILogger _logger;

        public EFormsProcessorExceptionHandler(ILogger logger)
        {
            _logger = logger;
        }

        public override async Task HandleAsync(ExceptionHandlerContext context, CancellationToken cancellationToken)
        {
            var errorMessage = context.Exception.Message;
            var response = context.Request.CreateErrorResponse(HttpStatusCode.InternalServerError, errorMessage);
            context.Result = new ResponseMessageResult(response);

            _logger.WriteError(errorMessage, context.Exception);
        }
    }
}