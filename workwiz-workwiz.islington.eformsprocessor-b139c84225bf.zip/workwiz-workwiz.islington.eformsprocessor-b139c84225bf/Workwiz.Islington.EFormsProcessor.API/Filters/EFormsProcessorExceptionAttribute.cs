﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;
using Microsoft.Owin.Logging;
using Workwiz.Islington.EFormsProcessor.Shared.Exceptions;

namespace Workwiz.Islington.EFormsProcessor.API.Filters
{
    public class EFormsProcessorExceptionAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            var telemetry = new Microsoft.ApplicationInsights.TelemetryClient();
            if (actionExecutedContext.Exception is EFormsProcessorException)
            {
                var efpException = actionExecutedContext.Exception as EFormsProcessorException;
                actionExecutedContext.Response = actionExecutedContext.Request.CreateErrorResponse(efpException.Status,
                    efpException.Message);

                var logger = actionExecutedContext.Request.GetOwinContext().Get<ILogger>("server.Logger");
                logger.WriteError(efpException.Message, efpException);
                telemetry.TrackException(efpException);
            }
            else
            {
                var logger = actionExecutedContext.Request.GetOwinContext().Get<ILogger>("server.Logger");
                logger.WriteError(actionExecutedContext.Exception.Message, actionExecutedContext.Exception);
                telemetry.TrackException(actionExecutedContext.Exception);
                if (actionExecutedContext.Exception.InnerException != null)
                {
                    logger.WriteError(actionExecutedContext.Exception.InnerException.Message, actionExecutedContext.Exception.InnerException);
                    telemetry.TrackException(actionExecutedContext.Exception.InnerException);
                }
            }
        }
    }
}