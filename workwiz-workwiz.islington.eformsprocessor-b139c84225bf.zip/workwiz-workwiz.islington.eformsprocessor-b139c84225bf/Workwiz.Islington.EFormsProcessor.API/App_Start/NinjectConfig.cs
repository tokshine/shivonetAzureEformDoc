﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Web;
using Ninject;
using Workwiz.Islington.EFormsProcessor.Services;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Workwiz.Common.Azure.DocumentDB;

namespace Workwiz.Islington.EFormsProcessor.API
{
    public static class NinjectConfig
    {
        public static Lazy<IKernel> CreateKernel = new Lazy<IKernel>(() =>
        {
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());

            RegisterServices(kernel);

            return kernel;
        });

        private static void RegisterServices(KernelBase kernel)
        {
            var fDocumentDbConnectionFactory =
                new DocumentDbConnectionFactory("FormsDb", Microsoft.Azure.Documents.ConsistencyLevel.Session);
            kernel.Bind<DocumentDbConnectionFactory>()
                .ToConstant(fDocumentDbConnectionFactory)
                .InSingletonScope()
                .Named("Forms");
            
            var wfDocumentDbConnectionFactory = 
                new DocumentDbConnectionFactory("WorkflowDb", Microsoft.Azure.Documents.ConsistencyLevel.Session);
            kernel.Bind<DocumentDbConnectionFactory>()
                .ToConstant(wfDocumentDbConnectionFactory)
                .InSingletonScope()
                .Named("Workflows");

            var tDocumentDbConnectionFactory = 
                new DocumentDbConnectionFactory("TemplateDb", Microsoft.Azure.Documents.ConsistencyLevel.Session);
            kernel.Bind<DocumentDbConnectionFactory>()
                .ToConstant(tDocumentDbConnectionFactory)
                .InSingletonScope()
                .Named("Templates");

            kernel.Bind<IFormService>().To<FormsService>();
            kernel.Bind<IWorkflowService>().To<WorkflowService>();
            kernel.Bind<IFormTemplateService>().To<FormTemplateService>();
            kernel.Bind<IQueueService>().To<QueueService>();
        }
    }
}