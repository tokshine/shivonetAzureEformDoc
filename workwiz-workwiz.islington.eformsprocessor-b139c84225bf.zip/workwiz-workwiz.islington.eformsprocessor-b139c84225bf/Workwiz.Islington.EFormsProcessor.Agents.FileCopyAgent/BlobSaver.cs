﻿using System;
using System.IO;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace Workwiz.Islington.EFormsProcessor.Agents.FileCopyAgent
{
    public class BlobSaver : ISaver
    {
        public void SaveToDestination(string pathAndName, Stream stream)
        {
            var storageAccount =
                CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            var client = storageAccount.CreateCloudBlobClient();
            var container = client.GetContainerReference(CloudConfigurationManager.GetSetting("ContainerName"));
            container.CreateIfNotExists();

            var blockBlob = container.GetBlockBlobReference(pathAndName);
            blockBlob.UploadFromStream(stream);
        }
    }
}
