﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Agents.FileCopyAgent
{
    public interface ISaver
    {
        void SaveToDestination(string pathAndName, Stream stream);
    }
}
