﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Agents.Shared;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.DocumentStore;
using System.Configuration;
using System.Dynamic;
using System.Net.Http;
using Newtonsoft.Json.Linq;

namespace Workwiz.Islington.EFormsProcessor.Agents.FileCopyAgent
{
    public class FileCopyAgent : BaseAgent
    {
        DocumentStore.Client.IDocumentStoreHttpClient _docApiClient = null;
        
        public FileCopyAgent(DocumentStore.Client.IDocumentStoreHttpClient docStoreApiClient) : base()
        {
            _docApiClient = docStoreApiClient;
            SubscriptionName = "FileCopyAgentSub";
        }
        public override string AgentName
        {
            get
            {
                return "FileCopyAgent";
            }
        }
        public override  Task Start()
        {
            Logger.Info("Initializing {0} agent ..", AgentName);
            base.Start();
            if (HasInitialized)
            {
                try
                {
                    Configuration myDllConfig =
       ConfigurationManager.OpenExeConfiguration(this.GetType().Assembly.Location);
                    // Get the appSettings section
                    AppSettingsSection myDllConfigAppSettings =
                           (AppSettingsSection)myDllConfig.GetSection("appSettings");
                    // return the desired field 
                    
                    //TODO refactor the steps below and create a method in base class for that.
                    //create topic
                    if (!_namespaceManager.TopicExists(InfrastructureSettings.FileCopyQueueTopic))
                    {
                        _namespaceManager.CreateTopic(InfrastructureSettings.FileCopyQueueTopic);
                    }
                    //create subscription
                    if (!_namespaceManager.SubscriptionExists(InfrastructureSettings.FileCopyQueueTopic, SubscriptionName))
                    {
                        _namespaceManager.CreateSubscription(InfrastructureSettings.FileCopyQueueTopic, SubscriptionName);
                    }

                    _subscriptionClient = SubscriptionClient.CreateFromConnectionString(InfrastructureSettings.ServiceBusConnection,
                   InfrastructureSettings.FileCopyQueueTopic, SubscriptionName);

                    _subscriptionClient.OnMessage(async m => 
                    {
                        m.Complete();
                        await Process(m);
                    }, new OnMessageOptions() { AutoComplete = false, AutoRenewTimeout = TimeSpan.FromMinutes(1) });
                    Logger.Info("{0} initialized successfully", AgentName);
                    return Task.FromResult(true);
                }
                catch (Exception ex)
                {

                    Logger.Error(ex, "Error while Initializing {0} ", AgentName);
                    HasInitialized = false;

                }


            }
            Logger.Error("Unable to initialize {0}", AgentName);
            return Task.FromResult(false);
        }

        public override async Task<AgentProcessingResult> Process(Microsoft.ServiceBus.Messaging.BrokeredMessage message)
        {
            Console.WriteLine($"Processing FileCopy message {message.Properties["FormId"]}");

            if (base.HasInitialized)
            {
                var step = message.GetBody<WorkflowStep>();
                string formId = message.Properties["FormId"].ToString();
                Console.WriteLine("Getting form...");
                var form = await _formsClient.GetFormById(formId);


                JObject o = JObject.FromObject(form.GetType().GetProperty("PdfForm").GetValue(form));

                bool status = false;
                if (o != null)
                {
                    var fileIdProperty = o.GetValue("FileId").ToString();
                    var fileNameProperty = o.GetValue("FileName").ToString();
                    if (!string.IsNullOrEmpty(fileIdProperty + fileNameProperty))
                    {
                        try
                        {
                            Console.WriteLine("Getting document link");
                            var downloadLink = _docApiClient.GenerateDocumentLink(fileIdProperty);
                            if (downloadLink != null)
                            {
                                Console.WriteLine("Getting document stream");
                                var client = new HttpClient();
                                var ms = await client.GetStreamAsync(downloadLink);

                                var saveType = step.Parameters["SaveType"].ToString();

                                if (!string.IsNullOrEmpty(saveType))
                                {
                                    var saver = SaverFactory.Create(saveType);
                                    var saveDestination = step.Parameters["Destination"].ToString();
                                    Console.WriteLine("Saving copy");
                                    saver.SaveToDestination(saveDestination + fileNameProperty, ms);
                                }

                                dynamic formSection = new ExpandoObject();
                                formSection.TaskCompleted = $"{step.Name} was  completed ";
                                formSection.FileName = fileNameProperty;
                                Console.WriteLine("Updating form");
                                status = UpdateForm(formId, "FileCopy", formSection);
                            }
                            Console.WriteLine($"File Copy processing successful? {status}");

                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                }

                return new AgentProcessingResult() { IsSuccessful = status, FormId = formId };

            }
            else
            {
                Console.WriteLine($"{AgentName} hasn't been initialized");
                return new AgentProcessingResult() { IsSuccessful = false };
            }
        }
       

        public override Task Stop()
        {
            return Task.FromResult(true);
        }
    }
}
