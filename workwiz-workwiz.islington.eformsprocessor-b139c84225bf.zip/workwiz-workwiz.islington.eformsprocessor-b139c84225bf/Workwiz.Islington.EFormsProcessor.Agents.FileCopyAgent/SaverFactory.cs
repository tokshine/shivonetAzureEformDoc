﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Agents.FileCopyAgent
{
    static class SaverFactory
    {
        public static ISaver Create(string saveType)
        {
            switch (saveType.ToLower())
            {
                case ("blob"):
                default:
                    return new BlobSaver();   
            }
        }
    }
}
