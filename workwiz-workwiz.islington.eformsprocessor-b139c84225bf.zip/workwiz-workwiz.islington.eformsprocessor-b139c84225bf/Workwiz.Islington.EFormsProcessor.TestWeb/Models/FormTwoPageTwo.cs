﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Workwiz.Islington.EFormsProcessor.TestWeb.Models
{
    public class FormTwoPageTwo
    {
        public string Q3Text { get; set; }
        public string Q3Answer { get; set; }
        public string Q4Text { get; set; }
        public string Q4Answer { get; set; }
    }
}