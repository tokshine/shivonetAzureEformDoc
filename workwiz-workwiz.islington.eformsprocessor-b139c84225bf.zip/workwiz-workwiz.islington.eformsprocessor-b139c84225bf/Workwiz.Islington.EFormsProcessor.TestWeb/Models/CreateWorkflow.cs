﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Workwiz.Islington.EFormsProcessor.TestWeb.Models
{
    public class CreateWorkflow
    {
        public string WorkflowId { get; set; }
        public string WorkflowType { get; set; }
        public string Step1Name { get; set; }
        public int Step1Number { get; set; }
        public bool Step1IsQueueable { get; set; }
        public string Step2Name { get; set; }
        public int Step2Number { get; set; }
        public bool Step2IsQueueable { get; set; }
        public string Step3Name { get; set; }
        public int Step3Number { get; set; }
        public bool Step3IsQueueable { get; set; }
        public string Step4Name { get; set; }
        public int Step4Number { get; set; }
        public bool Step4IsQueueable { get; set; }
    }
}