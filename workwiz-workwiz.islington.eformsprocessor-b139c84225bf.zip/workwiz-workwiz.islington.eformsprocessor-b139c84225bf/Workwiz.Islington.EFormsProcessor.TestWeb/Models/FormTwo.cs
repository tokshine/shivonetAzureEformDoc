﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Web;

namespace Workwiz.Islington.EFormsProcessor.TestWeb.Models
{
    public class FormTwo
    {
        public string FormId { get; set; }
        public FormTwoPageOne PageOne { get; set; }
        public FormTwoPageTwo PageTwo { get; set; }
    }
}