﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Workwiz.Islington.EFormsProcessor.TestWeb.Models
{
    public class FormThree
    {
        public string Id { get; set; }
        public string Q1Text { get; set; }
        public string Q1Answer { get; set; }
        public string Q2Text { get; set; }
        public string Q2Answer { get; set; }
        public string UserId { get; set; }
        public string BusinessId { get; set; }
    }
}