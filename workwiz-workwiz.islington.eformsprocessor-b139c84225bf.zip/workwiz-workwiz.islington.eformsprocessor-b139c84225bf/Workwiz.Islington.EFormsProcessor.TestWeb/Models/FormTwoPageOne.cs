﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Workwiz.Islington.EFormsProcessor.TestWeb.Models
{
    public class FormTwoPageOne
    {
        public string Q1Text { get; set; }
        public string Q1Answer { get; set; }
        public string Q2Text { get; set; }
        public string Q2Answer { get; set; }
    }
}