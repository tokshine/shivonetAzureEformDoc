﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Workwiz.Islington.EFormsProcessor.ApiClient;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.TestWeb.Models;

namespace Workwiz.Islington.EFormsProcessor.TestWeb.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult FormOne()
        {
            var model = new FormOne()
            {
                Q1Text = "Name",
                Q2Text = "Email",
                Q3Text = "Favourite colour",
                Q4Text = "Nationality"
            };
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> FormOne(FormOne model)
        {
            var form = new Form()
            {
                FormTemplateId = "OnePageTest",
                Response = new UserResponse() {  Answers = new Dictionary<string, UserResponseItem>() }
            };
            form.Response.Answers.Add("Q1", new UserResponseItem() {Question = model.Q1Text, Answer = model.Q1Answer});
            form.Response.Answers.Add("Q2", new UserResponseItem() { Question = model.Q2Text, Answer = model.Q2Answer });
            form.Response.Answers.Add("Q3", new UserResponseItem() { Question = model.Q3Text, Answer = model.Q3Answer });
            form.Response.Answers.Add("Q4", new UserResponseItem() { Question = model.Q4Text, Answer = model.Q4Answer });
            var client = new FormsClient();
            var savedForm = await client.Create(form);
            model.Id = savedForm.SubmittedFormId;
            return View("FormOneConfirm", model);
        }

        public ActionResult FormTwo()
        {
            var model = new FormTwo()
            {
                PageOne = new FormTwoPageOne() {
                    Q1Text = "Name",
                    Q2Text = "Email"
                },
                PageTwo = new FormTwoPageTwo() {
                    Q3Text = "Favourite colour",
                    Q4Text = "Nationality"
                }
            };
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> FormTwoPageTwo(FormTwo model)
        {
            var form = new Form()
            {
                FormTemplateId = "TwoPageTest",
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() }
            };
            form.Response.Answers.Add("Q1", new UserResponseItem() { Question = model.PageOne.Q1Text, Answer = model.PageOne.Q1Answer});
            form.Response.Answers.Add("Q2", new UserResponseItem() { Question = model.PageOne.Q2Text, Answer = model.PageOne.Q2Answer});
            var client = new FormsClient();
            var savedForm = await client.Create(form);
            model.FormId = savedForm.SubmittedFormId;
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> FormTwoConfirm(FormTwo model)
        {
            var client = new FormsClient();
            var form = await client.GetFormById(model.FormId);
            if (form != null)
            {
                form.Response.Answers.Add("Q3", new UserResponseItem() { Question = model.PageTwo.Q3Text, Answer = model.PageTwo.Q3Answer });
                form.Response.Answers.Add("Q4", new UserResponseItem() { Question = model.PageTwo.Q4Text, Answer = model.PageTwo.Q4Answer });
                await client.UpdateResponseProgressWorkflow(model.FormId, form.Response);
                return View(model);
            }
            return View();
        }

        public ActionResult FormThree()
        {
            var model = new FormThree()
            {
                Q1Text = "Name",
                Q2Text = "Email"
            };
            return View(model);
        }

        public async Task<ActionResult> FormThreePageTwo(FormThree model)
        {
            var form = new Form()
            {
                FormTemplateId = "TwoPageTest",
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() }
            };
            form.Response.Answers.Add("Q1", new UserResponseItem() { Question = model.Q1Text, Answer = model.Q1Answer });
            form.Response.Answers.Add("Q2", new UserResponseItem() { Question = model.Q2Text, Answer = model.Q2Answer });
            var client = new FormsClient();
            var savedForm = await client.Create(form);
            model.Id = savedForm.SubmittedFormId;
            return View(model);
        }

        public async Task<ActionResult> FormThreeConfirm(FormThree model)
        {
            var client = new FormsClient();
            var userDetails = new UserDetails()
                {
                    BusinessId = model.BusinessId,
                    Id = model.UserId
                };
                
            await client.UpdateUser(model.Id, userDetails);
            return View(model);
        }

        public ActionResult FormFour()
        {
            var model = new FormFour()
            {
                Q1Text = "Name",
                Q2Text = "Email"
            };
            return View(model);
        }
        
        public async Task<ActionResult> FormFourPageTwo(FormFour model)
        {
            var form = new Form()
            {
                FormTemplateId = "TwoPageTest",
                Response = new UserResponse() { Answers = new Dictionary<string, UserResponseItem>() },
                Workflow = new WorkflowDetails() { WorkflowId = "463758ef-39bd-b5bf-d9e8-4827dbc73a62" }
            };
            form.Response.Answers.Add("Q1", new UserResponseItem() { Question = model.Q1Text, Answer = model.Q1Answer });
            form.Response.Answers.Add("Q2", new UserResponseItem() { Question = model.Q2Text, Answer = model.Q2Answer });
            var client = new FormsClient();
            var savedForm = await client.Create(form);
            model.Id = savedForm.SubmittedFormId;
            model.WorkflowId = "463758ef-39bd-b5bf-d9e8-4827dbc73a62";
            return View(model);
        }

        public async Task<ActionResult> FormFourConfirm(FormFour model)
        {
            var client = new FormsClient();
            var workflow = new WorkflowDetails()
            {
                WorkflowId = model.WorkflowId,
                CurrentStepId = model.CurrentStepId
            };

            await client.UpdateWorkflow(model.Id, workflow);
            return View(model);
        }

        public ActionResult CreateWorkflow()
        {
            return View();
        }

        public async Task<ActionResult> CreateWorkflowConfirm(CreateWorkflow model)
        {
            var workflow = new Workflow()
            {
                WorkflowType = model.WorkflowType,
                Steps = new List<WorkflowStep>()
            };
            if (!string.IsNullOrEmpty(model.Step1Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step1Name,
                    Number = 1,
                    IsQueueable = model.Step1IsQueueable,
                    Parameters = new Dictionary<string, object>()
                });
            }
            if (!string.IsNullOrEmpty(model.Step2Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step2Name,
                    Number = 2,
                    IsQueueable = model.Step2IsQueueable
                });
            }
            if (!string.IsNullOrEmpty(model.Step3Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step3Name,
                    Number = 3,
                    IsQueueable = model.Step3IsQueueable
                });
            }
            if (!string.IsNullOrEmpty(model.Step4Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step4Name,
                    Number = 4,
                    IsQueueable = model.Step4IsQueueable
                });
            }
            workflow.Steps[0].Parameters.Add("Param1", 1);
            workflow.Steps[0].Parameters.Add("Param2", "Value2");
            var client = new WorkflowsClient();
            var newWorkflow = await client.Create(workflow);
            model.WorkflowId = newWorkflow.WorkflowId;
            return View(model);
        }

        public async Task<ActionResult> ListWorkflows()
        {
            var client = new WorkflowsClient();
            var workflowList = await client.GetAll();
            return View(workflowList);
        }

        public async Task<ActionResult> GetWorkflow(string id)
        {
            var client = new WorkflowsClient();
            var workflow = await client.GetById(id);
            return View(workflow);
        }

        public async Task<ActionResult> DeleteWorkflow(string id)
        {
            var client = new WorkflowsClient();
            var workflow = await client.GetById(id);
            await client.Delete(workflow);
            return View();
        }

        public async Task<ActionResult> EditWorkflow(string id)
        {
            var client = new WorkflowsClient();
            var workflow = await client.GetById(id);
            
            var editWorkflow = new CreateWorkflow()
            {
                WorkflowId = workflow.WorkflowId,
                WorkflowType = workflow.WorkflowType
            };
            if (workflow.Steps.Any())
            {
                editWorkflow.Step1Name = workflow.Steps[0].Name;
                editWorkflow.Step1Number = 1;
                editWorkflow.Step1IsQueueable = workflow.Steps[0].IsQueueable;
            }
            if (workflow.Steps.Count() > 1)
            {
                editWorkflow.Step2Name = workflow.Steps[1].Name;
                editWorkflow.Step2Number = 2;
                editWorkflow.Step2IsQueueable = workflow.Steps[1].IsQueueable;
            }
            if (workflow.Steps.Count() > 2)
            {
                editWorkflow.Step3Name = workflow.Steps[2].Name;
                editWorkflow.Step3Number = 3;
                editWorkflow.Step3IsQueueable = workflow.Steps[2].IsQueueable;
            }
            if (workflow.Steps.Count() > 3)
            {
                editWorkflow.Step4Name = workflow.Steps[3].Name;
                editWorkflow.Step4Number = 4;
                editWorkflow.Step4IsQueueable = workflow.Steps[3].IsQueueable;
            }

            return View(editWorkflow);
        }

        [HttpPost]
        public async Task<ActionResult> EditWorkflow(CreateWorkflow model)
        {
            var workflow = new Workflow()
            {
                WorkflowType = model.WorkflowType,
                Steps = new List<WorkflowStep>()
            };
            if (!string.IsNullOrEmpty(model.Step1Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step1Name,
                    Number = 1,
                    IsQueueable = model.Step1IsQueueable
                });
            }
            if (!string.IsNullOrEmpty(model.Step2Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step2Name,
                    Number = 2,
                    IsQueueable = model.Step2IsQueueable
                });
            }
            if (!string.IsNullOrEmpty(model.Step3Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step3Name,
                    Number = 3,
                    IsQueueable = model.Step3IsQueueable
                });
            }
            if (!string.IsNullOrEmpty(model.Step4Name))
            {
                workflow.Steps.Add(new WorkflowStep()
                {
                    Name = model.Step4Name,
                    Number = 4,
                    IsQueueable = model.Step4IsQueueable
                });
            }
            var client = new WorkflowsClient();
            await client.Update(workflow);
            return await ListWorkflows();
        }

        public async Task<ActionResult> ListTemplates()
        {
            var client = new FormTemplatesClient();
            var templates = await client.GetAll();
            return View(templates);
        }

        public async Task<ActionResult> GetTemplateById(string id)
        {
            var client = new FormTemplatesClient();
            var template = await client.GetById(id);
            return View("TemplateDetails", template);
        }

        public async Task<ActionResult> GetTemplateByForm(string name)
        {
            var client = new FormTemplatesClient();
            var template = await client.GetByFormName(name);
            return View("TemplateDetails", template);
        }

        public async Task<ActionResult> GetTemplateByWorkflow(string type)
        {
            var client = new FormTemplatesClient();
            var template = await client.GetByWorkflow(type);
            return View("TemplateDetails", template);
        }

        public async Task<ActionResult> DeleteTemplate(string id)
        {
            var client = new FormTemplatesClient();
            await client.Delete(id);
            return View();
        }

        public async Task<ActionResult> CreateTemplate()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> CreateTemplateConfirm(FormTemplate template)
        {
            var client = new FormTemplatesClient();
            var newTemplate = await client.Create(template);
            return View(newTemplate);
        }
    }
}