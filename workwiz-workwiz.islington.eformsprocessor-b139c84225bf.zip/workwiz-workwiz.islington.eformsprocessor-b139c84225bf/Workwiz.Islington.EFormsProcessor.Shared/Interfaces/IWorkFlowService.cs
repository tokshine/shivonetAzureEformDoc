﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IWorkflowService
    {
        Task<Workflow> GetAsync(string id);
        Task<Workflow> GetByTypeAsync(string workflowType);
        Task<Workflow> CreateAsync(Workflow wf);
        Task UpdateAsync(Workflow wf);
        Task<List<Workflow>> GetAllAsync();
        Task DeleteAsync(string id);
        Task<WorkflowStep> GetNextStepAsync(string workflowId, string step);
        Task<WorkflowStep> GetNextStepAsync(string workflowId, int stepNumber);
        Task<WorkflowStep> GetPreviousStepAsync(string workflowId, int stepNumber);
        Task<WorkflowStep> GetCurrentStepNumberAsync(string workflowId, int stepNumber);
    }
}
