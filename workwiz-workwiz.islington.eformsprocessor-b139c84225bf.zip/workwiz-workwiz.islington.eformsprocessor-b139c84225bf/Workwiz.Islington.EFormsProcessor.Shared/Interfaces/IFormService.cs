﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IFormService
    {
        Task<Form> GetAsync(string id);
        Task<Form> CreateAsync(Form form);
        Task UpdateAsync(Form form);
        Task<List<Form>> GetAllAsync();
        Task DeleteAsync(string id);
    }
}
