﻿using Workwiz.Islington.EFormsProcessor.Shared.Entities;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IQueueService
    {
        void CreateQueueItem(WorkflowStep step, string formId);
    }


}
