﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IWorkflowApi
    {
        Task<Workflow> GetById(string workflowId);
        Task<List<Workflow>> GetAll();
        Task<List<Workflow>> Get(object searchParameters);
        Task<Workflow> Create(Workflow workflow);
        Task<Workflow> Update(Workflow workflow);
        Task Delete(Workflow workflow);
    }
}
