﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IFormTemplateService
    {
        Task<FormTemplate> GetAsync(string id);
        Task<FormTemplate> GetByNameAsync(string templateName);
        Task<List<FormTemplate>> GetByFormNameAsync(string formName);
        Task<List<FormTemplate>> GetAllAsync();
        Task<FormTemplate> CreateAsync(FormTemplate formTemplate);
        Task UpdateAsync(FormTemplate formTemplate);
        Task DeleteAsync(string templateId);
    }
}