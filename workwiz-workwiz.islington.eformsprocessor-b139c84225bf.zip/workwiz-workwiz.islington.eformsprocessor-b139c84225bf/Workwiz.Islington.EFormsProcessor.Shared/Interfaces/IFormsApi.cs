﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Enums;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IFormsApi
    {
        Task<Form> GetFormById(string formId);
        Task<List<Form>> Search(object searchParameters);
        Task<Form> Create(Form form);
        Task<Form> UpdateResponse(string formId, UserResponse userResponse);
        Task<Form> UpdateResponseProgressWorkflow(string formId, UserResponse userResponse, WorkflowDirection nextStep = WorkflowDirection.Next);

        [Obsolete("Use \"UpdateResponseProgressWorkflow\" instead")]
        Task<Form> UpdateFormProgressWorkflow(string formId, string stepName, dynamic formSection, WorkflowDirection nextStep = WorkflowDirection.Next);

        Task<Form> UpdateUser(string formId, UserDetails userDetails);
        Task<Form> UpdateWorkflow(string formId, WorkflowDetails workflow, WorkflowDirection nextStep = WorkflowDirection.Next);

        Task<Workflow> GetFormWorkflowSteps(string formId);

        Task<string> GetHtmlById(string formId );
    }
}
