﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IFormTemplateApi
    {
        Task<FormTemplate> GetById(string id);
        Task<FormTemplate> GetByWorkflow(string type);
        Task<FormTemplate> GetByFormName(string name);
        Task<List<FormTemplate>> GetAll();
        Task<FormTemplate> Create(FormTemplate template);
        Task<FormTemplate> Update(FormTemplate template);
        Task Delete(string templateId);
    }
}
