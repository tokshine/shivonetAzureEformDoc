﻿using Microsoft.ServiceBus.Messaging;
using System.Collections.Generic;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;

namespace Workwiz.Islington.EFormsProcessor.Shared.Interfaces
{
    public interface IFormAgent
    {
        string AgentName { get;}
        Task<AgentProcessingResult> Process(BrokeredMessage message);
        Task Start();
        Task Stop();
    }
}
