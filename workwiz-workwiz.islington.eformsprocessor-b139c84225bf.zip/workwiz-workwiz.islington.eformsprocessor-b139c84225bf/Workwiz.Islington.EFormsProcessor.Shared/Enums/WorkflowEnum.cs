﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Shared.Enums
{
    /// <summary>
    /// The directon of the workflow
    /// </summary>
    public enum WorkflowDirection
    {
        /// <summary>
        /// Go to the next work flow step
        /// </summary>
        Next = 0,
        /// <summary>
        /// Go to the previous work flow step
        /// </summary>
        Previous = 1,
        /// <summary>
        /// Stay on the current work flow step
        /// </summary>
        Current = 2,
    }
}
