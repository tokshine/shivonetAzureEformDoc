﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Shared.Exceptions
{
    public class EFormsProcessorException : Exception
    {
        public HttpStatusCode Status { get; set; }

        public EFormsProcessorException(HttpStatusCode status, string message) : base(message)
        {
            Status = status;
        }
    
    }
}
