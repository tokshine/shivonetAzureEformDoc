﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Shared.Entities
{
    public class Form
    {
        [JsonProperty(PropertyName = "id")]
        public string SubmittedFormId { get; set; }

        public string FormTemplateId { get; set; }

        public WorkflowDetails Workflow { get; set; }
        public UserResponse Response { get; set; }

        public UserDetails User { get; set; }

        public dynamic PdfForm { get; set; }

        public dynamic FileCopy { get; set; }
    }
}
