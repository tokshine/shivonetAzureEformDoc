﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Shared.Entities
{
    public class Workflow
    {
        [JsonProperty("id")]
        public string WorkflowId { get; set; }

        public string WorkflowType { get; set; }
        public List<WorkflowStep> Steps { get; set; }
    }
}
