﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Workwiz.Islington.EFormsProcessor.Shared.Entities
{
    public class FormTemplate
    {
        [JsonProperty("id")]
        public string TemplateId { get; set; }
        public string FormType { get; set; }
        public string WorkflowType { get; set; }
    }
}
