﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Workwiz.Islington.EFormsProcessor.Shared.Entities
{
    public class WorkflowStep
    {
        public string Name { get; set; }
        public int Number { get; set; }
        public bool IsQueueable { get; set; }
        public Dictionary<string, object> Parameters { get; set; }
    }
}
