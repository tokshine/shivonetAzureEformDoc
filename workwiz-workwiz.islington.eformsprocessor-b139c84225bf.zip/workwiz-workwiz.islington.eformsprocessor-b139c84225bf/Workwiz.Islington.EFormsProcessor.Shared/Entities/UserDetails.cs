﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Shared.Entities
{
    public class UserDetails
    {
        public string Id { get; set; }
        public string BusinessId { get; set; }
        
    }
}
