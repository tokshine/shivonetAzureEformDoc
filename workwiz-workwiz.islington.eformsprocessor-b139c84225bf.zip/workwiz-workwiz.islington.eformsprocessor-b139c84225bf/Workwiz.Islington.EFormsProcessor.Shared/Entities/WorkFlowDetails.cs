﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Shared.Entities
{
    public class WorkflowDetails
    {
        public string WorkflowId { get; set; }
        [Obsolete("please use CurrentStepNumber instead.")]
        public string CurrentStepId { get; set; }
        public int FurthestStepNumber { get; set; }
        public int CurrentStepNumber { get; set; }
    }
}
