﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Shared.Entities
{
    public class AgentProcessingResult
    {
        [JsonProperty("id")]
        public string ResultId { get; set; }
        public string FormId { get; set; }
        public string Step { get; set; }

        public int FailedAttempts { get; set; }
        public bool IsSuccessful { get; set; }
    }
}
