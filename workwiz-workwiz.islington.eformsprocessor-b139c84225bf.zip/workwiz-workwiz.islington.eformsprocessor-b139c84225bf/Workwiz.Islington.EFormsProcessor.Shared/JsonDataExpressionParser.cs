﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace Workwiz.Islington.EFormsProcessor.Shared
{
    /// <summary>
    /// Methods for parsing data-expressions for flexibly configuration of text via configuration parameters
    /// NOTE: copy-pasted and extended from workwiz's PlayServices.Shared.DataExpression
    /// </summary>
    public static class JsonDataExpressionParser
    {
        /// <summary>
        /// Similar to Databinder.Eval but with inline expressions and supporting multiple databindings in a single expression.
        /// expressions must be in the form of a JPath
        /// examples:
        /// TODO: write some examples
        /// </summary>
        /// <param name="dataContainer">the data-structure which JPath expressions will be evaluated on - will typically be a JObject</param>
        /// <param name="expression">An expression containing an arbitrary mixture of static content and JPath expressions, i.e. "Upload{metadata.UploadTime}_for{form.question3.answer}"</param>
        /// <remarks>
        /// TODO: write unit tests
        /// TODO: support escaping of curly brackets so we can have output that contains curly braces
        /// TODO: support standard dotNet format-specifiers
        /// TODO: rewrite to use Regex.Replace method with a MatchEvaluator instead
        /// </remarks>
        /// <returns></returns>
        public static string Eval(JToken dataContainer, string expression, bool throwOnError = false)
        {
            if (null == dataContainer)
            {
                dataContainer = new JObject();
            }

            string result = expression;

            Regex expressionFinder = new Regex(@"\{([^\}\s]+)\}", RegexOptions.Compiled);
            foreach (Match match in expressionFinder.Matches(expression))
            {
                string replaceExpression = match.Groups[0].Value;
                string evalExpression = match.Groups[1].Value;
                try
                {
                    JToken retrievedNode = dataContainer.SelectToken(evalExpression, throwOnError);
                    if (null != retrievedNode)
                    {
                        string evaluatedBinding = retrievedNode.ToString(Newtonsoft.Json.Formatting.None);
                        result = result.Replace(replaceExpression, evaluatedBinding);
                    }

                }
                catch (Exception ex)
                {
//                    Logger.CreateEntry(LogLevel.Warn, string.Format("Expression binding {0} to {1} failed", expression, container), ex);
                    if (throwOnError)
                    {
                        throw;
                    }
                }
            }
            return result;
        }
    }
}