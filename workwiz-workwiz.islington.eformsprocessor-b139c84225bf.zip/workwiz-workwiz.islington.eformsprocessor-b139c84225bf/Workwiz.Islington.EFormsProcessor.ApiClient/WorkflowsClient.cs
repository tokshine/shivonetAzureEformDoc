﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;

namespace Workwiz.Islington.EFormsProcessor.ApiClient
{
    public class WorkflowsClient : IWorkflowApi
    {
        public async Task<Workflow> GetById(string workflowId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"workflows/{workflowId}");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Workflow>(responsestring);
            }
        }

        public async Task<List<Workflow>> GetAll()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"workflows");
                var responsestring = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<Workflow>>(responsestring);
            }
        }

        public Task<List<Workflow>> Get(object searchParameters)
        {
            throw new NotImplementedException();
        }

        public async Task<Workflow> Create(Workflow workflow)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.PostAsJsonAsync("workflows", workflow);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Workflow>(responsestring);
            }
        }

        public async Task<Workflow> Update(Workflow workflow)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.PutAsJsonAsync($"workflows/{workflow.WorkflowId}", workflow);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Workflow>(responsestring);
            }
        }

        public async Task Delete(Workflow workflow)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                await client.DeleteAsync("workflows/" + workflow.WorkflowId);
            }
        }
    }
}
