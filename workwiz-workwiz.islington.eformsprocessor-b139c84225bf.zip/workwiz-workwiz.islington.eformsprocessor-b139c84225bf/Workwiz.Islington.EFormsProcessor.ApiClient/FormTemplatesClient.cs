﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;

namespace Workwiz.Islington.EFormsProcessor.ApiClient
{
    public class FormTemplatesClient : IFormTemplateApi
    {
        public async Task<FormTemplate> GetById(string id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"templates/{id}");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<FormTemplate>(responsestring);
            }
        }

        public async Task<FormTemplate> GetByWorkflow(string type)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"templates/name/{type}");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<FormTemplate>(responsestring);
            }
        }

        public async Task<FormTemplate> GetByFormName(string name)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"templates/form/{name}");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<FormTemplate>(responsestring);
            }
        }

        public async Task<List<FormTemplate>> GetAll()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"templates");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<List<FormTemplate>>(responsestring);
            }
        }

        public async Task<FormTemplate> Create(FormTemplate template)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.PostAsJsonAsync($"templates", template);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<FormTemplate>(responsestring);
            }
        }

        public async Task<FormTemplate> Update(FormTemplate template)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.PutAsJsonAsync($"templates/{template.TemplateId}", template);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<FormTemplate>(responsestring);
            }
        }

        public async Task Delete(string templateId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                await client.DeleteAsync($"templates/{templateId}");
            }
        }
    }
}
