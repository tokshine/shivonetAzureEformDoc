﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Marvin.JsonPatch;
using Marvin.JsonPatch.Dynamic;
using Newtonsoft.Json;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Workwiz.Islington.EFormsProcessor.Shared.Enums;

namespace Workwiz.Islington.EFormsProcessor.ApiClient
{
    public class FormsClient : IFormsApi
    {
        public async Task<Form> GetFormById(string formId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"forms/{formId}");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Form>(responsestring);
            }
        }

        public Task<List<Form>> Search(object searchParameters)
        {
            throw new NotImplementedException();
        }

        public async Task<Form> Create(Form form)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);

                var response = await client.PostAsJsonAsync("forms", form);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Form>(responsestring);

            }
        }

        public async Task<Form> UpdateResponse(string formId, UserResponse userResponse)
        {
            JsonPatchDocument<Form> patchDocument = new JsonPatchDocument<Form>();
            patchDocument.Replace(f => f.Response, userResponse);
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);

                // serialize
                var serializedItemToUpdate = JsonConvert.SerializeObject(patchDocument);

                // create the patch request
                var method = new HttpMethod("PATCH");
                var request = new HttpRequestMessage(method, $"forms/{formId}/response")
                {
                    Content = new StringContent(serializedItemToUpdate,
                    System.Text.Encoding.Unicode, "application/json")
                };

                // send it, using an HttpClient instance
                var response = await client.SendAsync(request);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Form>(responsestring);
            }
        }

        public async Task<Form> UpdateResponseProgressWorkflow(string formId, UserResponse userResponse, WorkflowDirection direction = WorkflowDirection.Next)
        {
            JsonPatchDocument<Form> patchDocument = new JsonPatchDocument<Form>();
            patchDocument.Replace(f => f.Response, userResponse);
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);

                // serialize
                var serializedItemToUpdate = JsonConvert.SerializeObject(patchDocument);

                // create the patch request
                var method = new HttpMethod("PATCH");
                var request = new HttpRequestMessage(method, $"forms/{formId}/workflowDirection/{direction}/response")
                {
                    Content = new StringContent(serializedItemToUpdate,
                    System.Text.Encoding.Unicode, "application/json")
                };

                // send it, using an HttpClient instance
                var response = await client.SendAsync(request);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Form>(responsestring);
            }
        }

        /// <summary>
        /// Updates the form progress workflow.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="stepName">Name of the step.</param>
        /// <param name="stepCompleted">The step completed.</param>
        /// <returns></returns>
        [Obsolete("Use UpdateResponseProgressWorkflow instead")]
        public async Task<Form> UpdateFormProgressWorkflow(string formId, string stepName, dynamic stepCompleted, WorkflowDirection direction = WorkflowDirection.Next)
        {
            var patchDocument = new JsonPatchDocument();
            patchDocument.Add(stepName, stepCompleted);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);

                // serialize
                var serializedItemToUpdate = JsonConvert.SerializeObject(patchDocument);

                // create the patch request
                var method = new HttpMethod("PATCH");
                var request = new HttpRequestMessage(method, $"forms/{formId}/workflowDirection/{direction}/dynamic")
                {
                    Content = new StringContent(serializedItemToUpdate,
                    System.Text.Encoding.Unicode, "application/json")
                };

                // send it, using an HttpClient instance
                var response = await client.SendAsync(request);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Form>(responsestring);
            }
        }

        public async Task<Form> UpdateUser(string formId, UserDetails userDetails)
        {
            JsonPatchDocument<Form> patchDocument = new JsonPatchDocument<Form>();
            patchDocument.Replace(f => f.User, userDetails);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);

                // serialize
                var serializedItemToUpdate = JsonConvert.SerializeObject(patchDocument);

                // create the patch request
                var method = new HttpMethod("PATCH");
                var request = new HttpRequestMessage(method, $"forms/{formId}/user")
                {
                    Content = new StringContent(serializedItemToUpdate,
                    System.Text.Encoding.Unicode, "application/json")
                };

                // send it, using an HttpClient instance
                var response = await client.SendAsync(request);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Form>(responsestring);
            }
        }

        public async Task<Form> UpdateWorkflow(string formId, WorkflowDetails workflow, WorkflowDirection direction = WorkflowDirection.Next)
        {
            JsonPatchDocument<Form> patchDocument = new JsonPatchDocument<Form>();
            patchDocument.Replace(f => f.Workflow, workflow);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);

                // serialize
                var serializedItemToUpdate = JsonConvert.SerializeObject(patchDocument);

                // create the patch request
                var method = new HttpMethod("PATCH");
                var request = new HttpRequestMessage(method, $"forms/{formId}/workflowDirection/{direction}/workflow")
                {
                    Content = new StringContent(serializedItemToUpdate,
                    System.Text.Encoding.Unicode, "application/json")
                };

                // send it, using an HttpClient instance
                var response = await client.SendAsync(request);
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Form>(responsestring);
            }
        }

        public async Task<string> GetHtmlById(string formId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"forms/{formId}/html");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<string>(responsestring);
            }
        }

        public async Task<Workflow> GetFormWorkflowSteps(string formId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Properties.Settings.Default.BaseApiAddress);
                var response = await client.GetAsync($"forms/{formId}/getFormWorkflowSteps");
                var responsestring = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<Workflow>(responsestring);
            }
        }
    }
}
