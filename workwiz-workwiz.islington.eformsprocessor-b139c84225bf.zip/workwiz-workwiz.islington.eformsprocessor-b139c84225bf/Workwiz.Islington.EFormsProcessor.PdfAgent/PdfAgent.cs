﻿using System;
using System.Dynamic;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using RazorTemplates.Core;
using WebSupergoo.ABCpdf9;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Agents.Shared;
using Workwiz.Islington.DocumentStore.Client;
using Workwiz.Islington.DocumentStore.Shared;

namespace Workwiz.Islington.EFormsProcessor.Agents.PdfAgent
{

    public class PdfAgent : BaseAgent
    {
        //private IRazorEngineService _razorService;

        public PdfAgent() : base()
        {
            SubscriptionName = "PdfAgentSub";
        }

        public override Task Start()
        {
            Logger.Info("Initalizing agent ..");
            base.Start();
            if (HasInitialized)
            {
                try
                {
                    //TODO refactory the steps below and create a method in base class for that.
                    //create topic
                    if (!_namespaceManager.TopicExists(InfrastructureSettings.PdfQueueTopic))
                    {
                        _namespaceManager.CreateTopic(InfrastructureSettings.PdfQueueTopic);
                    }
                    //create subscription
                    if (!_namespaceManager.SubscriptionExists(InfrastructureSettings.PdfQueueTopic, SubscriptionName))
                    {
                        _namespaceManager.CreateSubscription(InfrastructureSettings.PdfQueueTopic, SubscriptionName);
                    }

                    _subscriptionClient = SubscriptionClient.CreateFromConnectionString(InfrastructureSettings.ServiceBusConnection,
                   InfrastructureSettings.PdfQueueTopic, SubscriptionName);

                    _subscriptionClient.OnMessage(m =>
                    {
                        m.Complete();
                        Process(m);
                    }, new OnMessageOptions() { AutoComplete = false, AutoRenewTimeout = TimeSpan.FromMinutes(1) });
                    Logger.Info("PDF Agent initalized successfully");
                    //var templateFolderPath = Path.Combine(Path.GetDirectoryName(typeof(").Assembly.Location), "HtmlTemplates");

                    //var assembly = Assembly.GetExecutingAssembly();
                    //var resourceName = "Workwiz.Islington.EFormsProcessor.Agents.PdfAgent.Form.cshtml";

 

                    //using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                    //using (StreamReader reader = new StreamReader(stream))
                    //{
                    //    formTemplate = reader.ReadToEnd();
                    //}

                    //var config = new TemplateServiceConfiguration
                    //{
                    //    TemplateManager = new DelegateTemplateManager()
                    //};
                    
                    //_razorService = RazorEngineService.Create(config);

                    //Engine.Razor = _razorService;
                    //Engine.Razor.AddTemplate("Form", formTemplate);
                    //Engine.Razor.Compile("Form", null);

                    return Task.FromResult(true);
                }
                catch (Exception ex)
                {
                    //TODO log
                    HasInitialized = false;
                    //throw;
                }


            }
            Logger.Error("Unable to initialize Agent");



            return Task.FromResult(true);
        }

        public override string AgentName
        {
            get
            {
                return "PdfAgent";
            }
        }

        public override SqlFilter GetSubscriberFilters()
        {
            var filter = new SqlFilter("Type ='pdf' ");
            return filter;
        }

        public override async Task<AgentProcessingResult> Process(BrokeredMessage message)
        {
            if (XSettings.InstallLicense(
                    "X/VKS08wmMhAtn4jNv3DOcikae8bCdcYlqznwb21WBltkg7FeDm+CqofKHk/hAUJCMkw/yNFpEQVyKggS759xk0tZGCZB3NV42ERQ8qoKE7g5QnEoIE6faKxXECzZmgzRqd0V89ZskpwdxB7oTWBPk1TZzqRSWXq5eQ37UYvXPvVwaEo8gH942TFp7Yo4xpRYkw282dZzn/aMRgwBqRMqytvqQbsI/BaIeneE0ukIoPAI1Q00MSSFj9DhxKYMZqSosIciBS5X3GU3lc="))
            {
                Console.WriteLine("ABCpdf licence installed");
            }
            Console.WriteLine($"Processing PDF message {message.Properties["FormId"]}");

            var step = message.GetBody<WorkflowStep>();
            var status = false;

            string formId = message.Properties["FormId"].ToString();
            try
            {
                var html = GenerateHtml(formId, step.Parameters["Template"].ToString());
                var documentId = await GenerateSavePdf(step.Parameters["NameFormat"].ToString(), formId, html);
                if (!string.IsNullOrEmpty(documentId))
                {
                    dynamic formSection = new ExpandoObject();
                    formSection.TaskCompleted = $"{step.Name} was  completed ";
                    formSection.FileName = string.Format(step.Parameters["NameFormat"].ToString(), formId);
                    formSection.FileId = documentId;

                    status = UpdateForm(formId, "PdfForm", formSection);
                }
                Console.WriteLine($"PDF processing successful? {status}");

                return (new AgentProcessingResult() {IsSuccessful = status, FormId = formId});
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return (new AgentProcessingResult() { IsSuccessful = false, FormId = formId });
        }

        public override Task Stop()
        {
            return null;
        }

        #region Private methods
        private async Task<string> GenerateSavePdf(string nameFormat, string formId, string htmlstring)
        {
            Console.WriteLine("Saving PDF");
            Doc converter = new Doc();
            try
            {
                converter.Rect.SetRect(36, 56, 540, 700);
                converter.AddImageHtml(htmlstring);
                converter.HtmlOptions.Paged = true;

                var client = new DocumentStoreHttpClient();
                
                var documentId = await client.CreateDocument(new DocumentDto()
                {
                    FileName = string.Format(nameFormat, formId),
                    FileType = "application/pdf",
                    Stream = converter.GetStream()
                }, 1, 0, formId, string.Empty, string.Empty);

                converter.Clear();
                converter.Dispose();

                Console.WriteLine($"Saved PDF id: {documentId}");

                return documentId;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
            finally
            {
                converter.Dispose();
            }
        }

        /// <summary>
        /// Generate Html
        /// </summary>
        /// <param name="form"></param>
        private string GenerateHtml(string formId, string template)
        {
            Console.WriteLine("Generating HTML");
            var form = _formsClient.GetFormById(formId).Result;
            var templateString = ReadTemplate(template);
            var formTemplate = Template.Compile($"{templateString}");
            var output = formTemplate.Render(form);

            Console.WriteLine("Generated HTML");
            return output;
        }

        private string ReadTemplate(string templateKey)
        {
            using (var stream = typeof(PdfAgent).Assembly.GetManifestResourceStream(typeof(PdfAgent).Assembly.GetName().Name + ".HtmlTemplates." + templateKey + ".cshtml"))
            {
                if (stream == null)
                    throw new Exception($"Couldn't load resource 'Form.cshtml' from assembly {typeof(PdfAgent).Assembly.FullName}");

                using (var reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
        }
        
        #endregion
    }
}
