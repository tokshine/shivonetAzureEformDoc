﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Workwiz.Islington.EFormsProcessor.ApiClient;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Microsoft.ServiceBus;
using Workwiz.Islington.EFormsProcessor.Shared.Properties;
using NLog;

namespace Workwiz.Islington.EFormsProcessor.Agents.Shared
{
    public abstract class BaseAgent : IFormAgent
    {
        protected FormsClient  _formsClient = new FormsClient();
        protected Form _savedForm = null;
        protected SubscriptionClient _subscriptionClient;
        protected NamespaceManager _namespaceManager;
        protected MessagingFactory _msgfactory;
        protected TopicClient _topicClient;
        protected NLog.Logger Logger { get; private set; }
        protected Settings InfrastructureSettings { get { return Settings.Default; } }
        protected bool HasInitialized { get; set; }
        protected string SubscriptionName { get; set; }
        public BaseAgent() {

            Logger = LogManager.GetLogger(GetType().FullName);
        }
        public virtual SqlFilter GetSubscriberFilters()
        {
            return new SqlFilter("1=1");
        }

        protected Form GetForm(string id)
        {
            _savedForm = _formsClient.GetFormById(id).Result;
            return _savedForm;

        }

        protected bool UpdateForm(string id, string propertyName, dynamic taskCompleted)
        {
            var client = new FormsClient();
            var
                savedForm = client.UpdateFormProgressWorkflow(id, propertyName, taskCompleted);
            if (savedForm.Result != null)
            {
                return true;
            }
            return false;

        }
        public abstract string AgentName { get; }

        public abstract Task<AgentProcessingResult> Process(BrokeredMessage message);
        
        public virtual Task Start()
        {
            try
            {
                Logger.Info("Initalizing base agent ..");
                string connString = InfrastructureSettings.ServiceBusConnection;
                _namespaceManager = NamespaceManager.CreateFromConnectionString(connString);
                _msgfactory = MessagingFactory.CreateFromConnectionString(connString);
               
                HasInitialized = true;
                Logger.Info("Base agent initialized successfully ..");
                return Task.FromResult(HasInitialized);
            }
            catch (Exception e)
            {
                
                Logger.Fatal(e,"Error while initializing base agent");
                throw;
            }
        }

        public abstract Task Stop();
        
    }
}
