﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Agents.Shared
{
    //public class Settings
    //{
    //    public static string ConnectionString = "Endpoint=sb://lbiwwintdev.servicebus.windows.net/;SharedAccessKeyName=EFormsKey;SharedAccessKey=t8a9CrA7wQNDqEP5Jkb3wCoY/BjJrZAyIJ+SHBAm/YY=";
    //    public static string TOPIC_NAME = "formWorkflowTopic";
    //    public static string SUBSCRIPTION_NAME = "formWorkflowSub";
    //}
}
