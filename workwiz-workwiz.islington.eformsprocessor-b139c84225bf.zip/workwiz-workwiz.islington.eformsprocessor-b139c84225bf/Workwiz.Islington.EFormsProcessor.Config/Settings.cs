﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workwiz.Islington.EFormsProcessor.Config
{
    public class Settings
    {
        public static string ConnectionString = ;
        public static string TOPIC_NAME = "formWorkflowTopic";
        public static string SUBSCRIPTION_NAME = "formWorkflowSub";
    }
}
