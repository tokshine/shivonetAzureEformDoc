﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents;
using System.Configuration;
namespace Workwiz.Islington.EFormsProcessor.DocDbTest
{
    class Program
    {
        static  void Main(string[] args)
        {
            var ep = new Uri (ConfigurationManager.AppSettings["endpointUrl"]);
            var key = ConfigurationManager.AppSettings["authKey"];
            var dbName= ConfigurationManager.AppSettings["dbName"];
            var collectionName = ConfigurationManager.AppSettings["collectionName"];
            var c = new DocumentClient(ep, key);
           
            var r=  CreateCollection(c,dbName,collectionName);
            Console.WriteLine(r.ToString());
        
        }
        private static bool CreateCollection(DocumentClient client,string dbName,string collectionName)
        {
            // Configure collections for maximum query flexibility including string range queries.
            //collectionInfo.IndexingPolicy = new IndexingPolicy(new RangeIndex(DataType.String) { Precision = -1 });

            // Here we create a collection with 100 RU/s.
           var c=  client.CreateDocumentCollectionAsync(
                UriFactory.CreateDatabaseUri(dbName),
                new DocumentCollection { Id = collectionName },
                new RequestOptions { OfferThroughput = 400 }).Result;

            return true;

        }

       
    }
}
