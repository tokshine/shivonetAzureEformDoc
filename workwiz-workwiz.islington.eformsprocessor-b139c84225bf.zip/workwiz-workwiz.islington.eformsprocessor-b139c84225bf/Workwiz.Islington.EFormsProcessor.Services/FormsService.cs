﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents;
using System.Configuration;
using Microsoft.Azure.Documents.Linq;
using Ninject;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Workwiz.Common.Azure.DocumentDB;

namespace Workwiz.Islington.EFormsProcessor.Services
{
    public class FormsService : IFormService
    {
        private readonly DocumentClient _client = null;
        private readonly Uri _defaultCollectionLink;
        private readonly string _dbName;
        private readonly string _collectionName;

        public FormsService([Named("Forms")]DocumentDbConnectionFactory documentDbConnectionFactory)
        {
            _client = documentDbConnectionFactory.Client;
            _collectionName = documentDbConnectionFactory.CollectionId;
            _dbName= documentDbConnectionFactory.DatabaseId;
            _defaultCollectionLink = documentDbConnectionFactory.DefaultCollectionLink;
            //documentDbConnectionFactory.EnsureDefaultDatabaseAndCollection();
        }
       
        public async Task<Form> CreateAsync(Form form)
        {
            var doc=await _client.CreateDocumentAsync(_defaultCollectionLink, form);
            form.SubmittedFormId = doc.Resource.Id;
            return form;
        }

        public async Task DeleteAsync(string id)
        {
            var form= _client.CreateDocumentQuery(_defaultCollectionLink).Where(x => x.Id== id).AsEnumerable().FirstOrDefault();
            
            if (form!=null)
            {
                await _client.DeleteDocumentAsync(form.SelfLink);
            }
            
        }

        public async Task<Form> GetAsync(string id)
        {
            var query = _client.CreateDocumentQuery<Form>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
                .Where(x => x.SubmittedFormId == id)
                .AsDocumentQuery<Form>();
            var response = await query.ExecuteNextAsync<Form>();

            return response.FirstOrDefault();
        }

        public async Task<List<Form>> GetAllAsync()
        {
            var query = _client.CreateDocumentQuery<Form>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
               .AsDocumentQuery();
            var response = await query.ExecuteNextAsync<Form>();

            return response.ToList();
        }

        public async Task UpdateAsync(Form form)
        {
            
                var document =_client.CreateDocumentQuery<Document>(_defaultCollectionLink).Where(x=>x.Id==form.SubmittedFormId).AsEnumerable().SingleOrDefault();

                if (document != null)
                {
                    await _client.ReplaceDocumentAsync(document.SelfLink,form);
                }
            
        }
    }
}
