﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Documents.Client;
using Workwiz.Common.Azure.DocumentDB;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json;
using Ninject;

namespace Workwiz.Islington.EFormsProcessor.Services
{
    public class FormTemplateService : IFormTemplateService
    {
        private readonly DocumentClient _client = null;
        private readonly Uri _defaultCollectionLink;
        private readonly string _dbName;
        private readonly string _collectionName;

        public FormTemplateService([Named("Templates")]DocumentDbConnectionFactory documentDbConnectionFactory)
        {
            _client = documentDbConnectionFactory.Client;
            _collectionName = documentDbConnectionFactory.CollectionId;
            _dbName = documentDbConnectionFactory.DatabaseId;
            _defaultCollectionLink = documentDbConnectionFactory.DefaultCollectionLink;
            //documentDbConnectionFactory.EnsureDefaultDatabaseAndCollection();
        }

        public async Task<FormTemplate> GetAsync(string id)
        {
            //var d = _client.CreateDocumentQuery(_defaultCollectionLink).Where(x => x.Id == id).AsEnumerable().FirstOrDefault();
            var query = _client.CreateDocumentQuery<FormTemplate>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
                .Where(x => x.TemplateId == id)
                .AsDocumentQuery<FormTemplate>();
            var response = await query.ExecuteNextAsync<FormTemplate>();

            return response.FirstOrDefault();
        }

        public async Task<FormTemplate> GetByNameAsync(string templateName)
        {
            //var d = _client.CreateDocumentQuery<FormTemplate>(_defaultCollectionLink).Where(x => x.WorkflowType == templateName).AsEnumerable().FirstOrDefault();
            var query = _client.CreateDocumentQuery<FormTemplate>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
                .Where(x => x.WorkflowType == templateName)
                .AsDocumentQuery<FormTemplate>();
            var response = await query.ExecuteNextAsync<FormTemplate>();

            return response.FirstOrDefault();
        }

        public async Task<List<FormTemplate>> GetByFormNameAsync(string formName)
        {
            //var d = _client.CreateDocumentQuery<FormTemplate>(_defaultCollectionLink).Where(x => x.FormType == formName).AsEnumerable();
            var query = _client.CreateDocumentQuery<FormTemplate>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
                .Where(x => x.FormType == formName)
                .AsDocumentQuery<FormTemplate>();
            var response = await query.ExecuteNextAsync<FormTemplate>();

            return response.ToList();
        }

        public async Task<List<FormTemplate>> GetAllAsync()
        {
            var query = _client.CreateDocumentQuery<FormTemplate>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
                .AsDocumentQuery();
            var response = await query.ExecuteNextAsync<FormTemplate>();

            return response.ToList();
        }

        public async Task<FormTemplate> CreateAsync(FormTemplate formTemplate)
        {
            var d = await _client.CreateDocumentAsync(_defaultCollectionLink, formTemplate);
            formTemplate.TemplateId = d.Resource.Id;
            return formTemplate;
        }

        public async Task UpdateAsync(FormTemplate formTemplate)
        {
            var document = _client.CreateDocumentQuery<Document>(_defaultCollectionLink).Where(x => x.Id == formTemplate.TemplateId).AsEnumerable().SingleOrDefault();

            if (document != null)
            {
                await _client.ReplaceDocumentAsync(document.SelfLink, formTemplate);
            }
        }

        public async Task DeleteAsync(string templateId)
        {
            var form = _client.CreateDocumentQuery(_defaultCollectionLink).Where(x => x.Id == templateId).AsEnumerable().FirstOrDefault();

            if (form != null)
            {
                await _client.DeleteDocumentAsync(form.SelfLink);
            }
        }

    }
}
