﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Workwiz.Islington.EFormsProcessor.Shared.Properties;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Settings = Workwiz.Islington.EFormsProcessor.Shared.Properties.Settings;

namespace Workwiz.Islington.EFormsProcessor.Services
{
    public class QueueService : IQueueService
    {

        private readonly NamespaceManager _queueManager;
        private readonly MessagingFactory _factory;

        private Settings InfrastructureSettings { get { return Settings.Default; } }


        public QueueService()
        {
            string connString = InfrastructureSettings.ServiceBusConnection;               
            _queueManager = NamespaceManager.CreateFromConnectionString(connString);
            _factory = MessagingFactory.CreateFromConnectionString(connString);
        }

        public void CreateQueueItem(WorkflowStep step, string formId)
        {
            var message = new BrokeredMessage (step) { MessageId = Guid.NewGuid().ToString(), Label = $"Message {step.Name} created  {DateTime.UtcNow}"};

            var topicName = "";
            message.Properties.Add("Type", step.Name);
            message.Properties.Add("FormId", formId);

            switch (step.Name.ToLower())
            {
                case "pdf":
                    topicName = InfrastructureSettings.PdfQueueTopic;
                    break;
                case "filecopy":
                    topicName = InfrastructureSettings.FileCopyQueueTopic;
                    break;
                case "email":
                    topicName = InfrastructureSettings.SendMailQueueTopic;
                    break;
            }
            try
            {
                if (!_queueManager.TopicExists(topicName))
                {
                    _queueManager.CreateTopic(topicName);
                }

                var client = _factory.CreateTopicClient(topicName);
                client.Send(message);
                client.Close();
            }
            catch (MessagingException messagingException)
            {
                Trace.Write(messagingException.Message);
                throw;
            }
        }
    }
}
