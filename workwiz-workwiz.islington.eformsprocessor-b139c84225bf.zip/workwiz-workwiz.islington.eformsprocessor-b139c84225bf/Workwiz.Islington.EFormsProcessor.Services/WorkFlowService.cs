﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workwiz.Islington.EFormsProcessor.Shared.Entities;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents;
using System.Configuration;
using System.Diagnostics;
using Microsoft.Azure.Documents.Linq;
using Ninject;
using Workwiz.Islington.EFormsProcessor.Shared.Interfaces;
using Workwiz.Common.Azure.DocumentDB;

namespace Workwiz.Islington.EFormsProcessor.Services
{
    public class WorkflowService : IWorkflowService
    {
        private readonly DocumentClient _client;
        private readonly Uri _defaultCollectionLink;
        private readonly string _dbName;
        private readonly string _collectionName;

        public WorkflowService([Named("Workflows")]DocumentDbConnectionFactory documentDbConnectionFactory)
        {
            _client = documentDbConnectionFactory.Client;
            _collectionName = documentDbConnectionFactory.CollectionId;
            _dbName = documentDbConnectionFactory.DatabaseId;
            _defaultCollectionLink = documentDbConnectionFactory.DefaultCollectionLink;
            Task.Run(async () => { await documentDbConnectionFactory.EnsureDefaultDatabaseAndCollection(); });
        }

        public async Task<Workflow> GetAsync(string id)
        {
            var query = _client.CreateDocumentQuery<Workflow>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
               .Where(x => x.WorkflowId == id)
               .AsDocumentQuery<Workflow>();
            var response = await query.ExecuteNextAsync<Workflow>();

            return response?.FirstOrDefault();
        }

        public async Task<Workflow> GetByTypeAsync(string workflowType)
        {
            var query = _client.CreateDocumentQuery<Workflow>(UriFactory.CreateDocumentCollectionUri(_dbName, _collectionName))
               .Where(x => x.WorkflowType == workflowType)
               .AsDocumentQuery<Workflow>();
            var response = await query.ExecuteNextAsync<Workflow>();

            return response.ToList().FirstOrDefault();
        }

        public async Task<Workflow> CreateAsync(Workflow wf)
        {
            var d = await _client.CreateDocumentAsync(_defaultCollectionLink, wf);
            wf.WorkflowId = d.Resource.Id;
            return wf;
        }

        public async Task UpdateAsync(Workflow wf)
        {
            var document = _client.CreateDocumentQuery<Document>(_defaultCollectionLink).Where(x => x.Id == wf.WorkflowId).AsEnumerable().SingleOrDefault();

            if (document != null)
            {
                await _client.ReplaceDocumentAsync(document.SelfLink, wf);
            }
        }

        public async Task<List<Workflow>> GetAllAsync()
        {
            Trace.Write("Start query");
            try
            {

                //return Task.FromResult(_client.CreateDocumentQuery<Workflow>(_defaultCollectionLink).ToList()).Result;

                //return new List<Workflow>() { new Workflow() {WorkflowId = "Thing", WorkflowType = "Type", Steps = new List<WorkflowStep>() { new WorkflowStep() {Name = "Bronwen", Number = 1} } } };

                var query =
                    _client.CreateDocumentQuery<Workflow>(UriFactory.CreateDocumentCollectionUri(_dbName,
                        _collectionName))
                        .AsDocumentQuery<Workflow>();

                var response = await query.ExecuteNextAsync<Workflow>();

                return response.ToList();

            }
            catch (Exception ex)
            {
                Trace.Write(ex.Message);
            }
            return null;
        }


        public async Task<WorkflowStep> GetNextStepAsync(string workflowId, string step)
        {
            var workflow = GetWorkFlow(workflowId);
            if (workflow != null)
            {
                if (string.IsNullOrEmpty(step))
                {
                    return await Task.FromResult(workflow.Steps.FirstOrDefault());
                }
                var currentStep = workflow.Steps.Where(ws => ws.Name == step).FirstOrDefault();
                if (currentStep != null)
                {
                    var nextStep = workflow.Steps.Where(ws => ws.Number == currentStep.Number + 1).SingleOrDefault();
                    return await Task.FromResult(nextStep);
                }
                else return null;
            }
            return null;
        }
        /// <summary>
        /// Gets the next step asynchronous. If no next step is found it will remain on the current step
        /// </summary>
        /// <param name="workflowId">The workflow identifier.</param>
        /// <param name="stepNumber">The step number.</param>
        /// <returns></returns>
        public async Task<WorkflowStep> GetNextStepAsync(string workflowId, int stepNumber)
        {
            WorkflowStep currentStep;
            var workflow = GetWorkFlowAndCurrentStep(workflowId, stepNumber, out currentStep);
            if (workflow != null && currentStep != null)
            {
                if (stepNumber != int.MinValue)
                {
                    var nextStep = workflow.Steps.Where(ws => ws.Number == currentStep.Number + 1).SingleOrDefault();
                    if (nextStep != null)
                        return await Task.FromResult(nextStep);
                }
                return await Task.FromResult(currentStep); // No next step found so return current step
            }
            return null;
        }

        /// <summary>
        /// Gets the current step number asynchronous.
        /// </summary>
        /// <param name="workflowId">The workflow identifier.</param>
        /// <param name="stepNumber">The step number.</param>
        /// <returns></returns>
        public async Task<WorkflowStep> GetCurrentStepNumberAsync(string workflowId, int stepNumber)
        {
            WorkflowStep currentStep;
            var workflow = GetWorkFlowAndCurrentStep(workflowId, stepNumber, out currentStep);
            if (currentStep != null)
                return await Task.FromResult(currentStep);
            return null;

        }

        /// <summary>
        /// Gets the previous step asynchronous. If no previous step is found it will remain on the current step
        /// </summary>
        /// <param name="workflowId">The workflow identifier.</param>
        /// <param name="step">The step.</param>
        /// <returns></returns>
        public async Task<WorkflowStep> GetPreviousStepAsync(string workflowId, int stepNumber)
        {
            WorkflowStep currentStep;
            var workflow = GetWorkFlowAndCurrentStep(workflowId, stepNumber, out currentStep);
            if (workflow != null && currentStep != null)
            {
                var prevStep = workflow.Steps.Where(ws => ws.Number == currentStep.Number - 1).FirstOrDefault();
                if (prevStep != null)
                    return await Task.FromResult(prevStep);
                else
                    return await Task.FromResult(currentStep);
            }
            return null;
        }

        public async Task DeleteAsync(string id)
        {
            var form = _client.CreateDocumentQuery(_defaultCollectionLink).Where(x => x.Id == id).AsEnumerable().FirstOrDefault();

            if (form != null)
            {
                await _client.DeleteDocumentAsync(form.SelfLink);
            }

        }

        private Workflow GetWorkFlow(string workflowId)
        {
            if (!string.IsNullOrEmpty(workflowId))
            {
                var workflow = _client.CreateDocumentQuery<Workflow>(_defaultCollectionLink).Where(w => w.WorkflowId == workflowId)
                   .AsEnumerable().FirstOrDefault();
                return workflow;
            }
            return null;
        }

        private Workflow GetWorkFlowAndCurrentStep(string workflowId, int stepNumber, out WorkflowStep currentStep)
        {
            currentStep = null;
            if (!string.IsNullOrEmpty(workflowId))
            {
                var workflow = GetWorkFlow(workflowId);
                if (workflow != null)
                {
                    if (stepNumber == int.MinValue)
                    {
                        if (workflow.Steps != null)
                            currentStep = workflow.Steps.FirstOrDefault();
                    }
                    else
                        currentStep = workflow.Steps.Where(ws => ws.Number == stepNumber).FirstOrDefault();
                }
                return workflow;
            }
            return null;
        }
    }
}
